# Core Concept: Civic Empire

## 1. The Core Idea
**Civic Empire** (working title) is a browser-based power simulator that blends city management, economic simulation, political strategy, and life simulation. 

Instead of starting as an omnipotent "mayor in the sky" like traditional city-builders, the player starts as an ordinary citizen. The core gameplay loop focuses on gradually building personal wealth, reputation, and influence to climb the societal ladder, eventually taking total control of the city.

## 2. Core Gameplay Loop & Progression

### Stage 1: Citizen
*   **Starting State:** Small apartment, basic job, low bank balance, zero influence.
*   **Actions:** 
    *   Work a job via simple, active mini-games (e.g., approving/rejecting applications).
    *   Buy, sell, and actively maintain properties.
    *   Manage personal stats (Health, Happiness, Money, Reputation).
*   **Goal:** Build enough Wealth and Reputation to apply for better jobs via the in-game job seekers website.

### Stage 2: Local Influence
*   **Jobs:** Property Inspector, Tax Officer, Housing Authority.
*   **Actions:** Player decisions begin to have minor impacts on the city (e.g., property approvals, local tax adjustments).
*   **Goal:** Leverage local authority to boost personal investments and reputation.

### Stage 3: Economic Authority
*   **Jobs:** Treasury Officer, Trade Commissioner.
*   **Actions:** Player gains access to macroeconomic levers. They can adjust interest rates, import taxes, and housing grants.
*   **Goal:** Manipulate the city's economy to favor personal assets while maintaining enough public stability to build a political platform.

### Stage 4: Politics
*   **Actions:** The player launches a political campaign for the top office.
*   **Mechanics:** Give speeches, promise policies, buy advertising. 
*   **Voting:** Citizens vote based on the current state of Employment, Housing, Crime, Inflation, and Trust.

### Stage 5: City Leader
*   **Roles:** Mayor / Governor.
*   **Actions:** Total control over taxes, infrastructure, and public spending.
*   **Goal:** Successfully maintain the city's stability and win re-election to complete the game.

## 3. Simplified Economic Engine
The game does not simulate a granular, real-world economy. Instead, it relies on a simplified engine of interconnected variables:

| Variable | Represents |
| :--- | :--- |
| **Employment** | Availability of jobs. High employment boosts trust; low boosts crime. |
| **Inflation** | Price growth. High inflation hurts citizens; deflation hurts business. |
| **Housing** | Cost of homes. Must balance investor profits vs. citizen affordability. |
| **Crime** | Public safety. High crime ruins property values and trust. |
| **Population** | Total citizens. Grows with prosperity, shrinks with hardship. |
| **City Trust** | Public confidence. The most important metric for political survival. |

*All player actions push and pull these variables.* 
*Example:* Lowering interest rates -> Businesses borrow more -> Housing demand rises -> Property prices rise -> Inflation rises. (Result: Employment +5, Housing Cost +10, Inflation +8, Trust +2).

## 4. Key Mechanics

### Time & Events
*   **Live Time:** 5 minutes real-time = 1 in-game day. Can be sped up 3x or paused.
*   **Event Pop-ups:** Time pauses for random events (e.g., Housing Crash, Tech Boom) or work-related scenarios where the player must choose between 3 preset options.

### Active Property Management
*   Properties generate passive income (rent, sales) but require active maintenance.
*   Players must spend money to press a "Maintain" button. Poorly maintained properties lose value over time.

### The Butterfly Effect
*   Every decision has delayed consequences. Cutting education today saves money immediately but causes an unemployment spike years later.

### Corruption & Risk
*   Players can take bribes or manipulate contracts to speed up wealth generation.
*   This generates "Heat." If exposed, trust crashes, ending political careers or resulting in a Game Over.

### Public Sentiment & Lobbying
*   **Lobby Groups:** Homeowners, Renters, Unions, Banks. Pleasing one group angers another.
*   **Perception vs. Reality:** If the economy is failing but the player controls the media narrative, public trust may stay high temporarily before reality catches up.

## 5. UI Presentation: The "Fake Internet"
Rather than presenting the player with dry spreadsheets, the game uses a simulated internet interface.

*   **Job Seeking:** Apply for promotions on a job portal.
*   **Economy Tracking:** Read news headlines (e.g., *"Housing Prices Reach Record High"*) instead of just looking at a line graph.
*   **Public Sentiment:** Check in-game social media to see what citizens are complaining about.
*   **Real Estate:** Buy and sell properties on a simulated property listing website.

## 6. Technical Stack
*   **Frontend:** HTML5, CSS3, Vanilla JavaScript.
*   **Design:** Mobile-friendly, responsive UI.
*   **Deployment:** Browser-based, easily hosted on GitHub Pages or standard web servers. No backend required for the core single-player experience.
