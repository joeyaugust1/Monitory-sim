# Civic Empire — Developer Log

**Project:** Civic Empire (Working Title)
**Type:** Single-player political power simulator
**Stack:** React 19 + TypeScript + Vite + TailwindCSS 4
**Session Date:** June 2026
**Current Version:** v0.4 MVP

---

## Overview

This log documents every decision, design choice, and implementation step taken during the initial development session of Civic Empire. It is intended as a living reference document for the developer to understand what was built, why it was built that way, and what remains to be done.

---

## Phase 1 — Concept Finalisation

### Starting Point

The session began with two draft documents provided by the developer:

- **Master Design Summary** — a structured outline of all game systems, covering the economy, property, business, career, political, election, citizen, media, currency, event, and public opinion systems.
- **Core Concept** — a higher-level narrative description of the five-stage player progression and the key mechanics that distinguish the game from a standard city-builder.

Both documents were strong outlines but lacked specificity in several critical areas. Before any code was written, a structured review was conducted to identify the gaps.

### Gaps Identified

The following areas were missing from the original drafts and were resolved through direct discussion:

| Gap | Resolution |
| :--- | :--- |
| **Time system** | Live real-time progression. 5 real-world minutes = 1 in-game day. Players can pause, run at 1× or 3× speed. Time auto-pauses on events. |
| **Player stats** | Four personal stats: Health, Happiness, Money, Reputation. Reputation is the primary career advancement metric. |
| **Career advancement** | Reputation-gated. Players earn rep through work decisions. Once the threshold is met, they apply via the in-game job portal. Top-tier positions are offered, not applied for. |
| **Work mini-game** | Active, job-specific mini-games. Stage 1 (Office Administrator) involves reviewing and approving or denying permit/grant applications. Each decision has flow-on effects. |
| **Property management** | Active maintenance required. A "Maintain" button costs $200 and restores condition to 100%. Neglected properties lose value over time. |

### Finalised Documents

Two polished design documents were produced:

1. `Civic_Empire_Master_Design_Summary.md` — The authoritative reference for all game systems, mechanics, and design philosophy.
2. `Civic_Empire_Core_Concept.md` — A concise narrative overview of the game's concept, loop, and technical stack.

---

## Phase 2 — Design Direction

Before writing any code, a formal design brainstorm was conducted and recorded in `ideas.md` inside the project directory.

Three stylistic approaches were considered:

- **Brutalist Newsroom** — Monochrome, editorial, financial newspaper aesthetic.
- **Neon Noir City** — Dark cyberpunk, glowing accents, Blade Runner-inspired.
- **Executive Dark — Political Thriller** — Premium dark-mode dashboard. Bloomberg Terminal meets The West Wing.

**Chosen approach: Executive Dark — Political Thriller.**

This was selected because it best matches the game's tone — a serious, high-stakes simulator where every decision carries weight. The design should feel like you are operating in a world of real consequence, not playing a casual game.

### Design System

| Element | Decision |
| :--- | :--- |
| **Background** | Deep charcoal `#0f1117` |
| **Surface** | Slate panels `#1a1f2e` |
| **Signature colour** | Amber Gold `oklch(0.72 0.15 75)` — used for key data, CTAs, and highlights |
| **Positive indicator** | Electric Teal / Emerald |
| **Negative indicator** | Crimson Red |
| **Display font** | Playfair Display (serif) — for headings and the game title |
| **UI font** | IBM Plex Sans — for all interface text |
| **Data font** | IBM Plex Mono — for all numbers, stats, and code-style values |
| **Border radius** | 0.35rem — deliberately sharp, not soft |
| **Animation** | Snappy ease-out (cubic-bezier 0.23, 1, 0.32, 1), under 300ms |

---

## Phase 3 — Visual Assets

Three AI-generated images were produced and hosted on the CDN for use in the game:

| Asset | Usage | URL Key |
| :--- | :--- | :--- |
| **Logo / Crest** | Amber gold city skyline shield on transparent background. Used in header and splash screen. | `civic-empire-logo` |
| **City Night Background** | Cinematic aerial city at night, amber and teal lighting, government dome in the distance. Used as the main map background and splash overlay. | `civic-empire-city-bg` |
| **Splash Background** | Dark blueprint/map texture with faint amber crest watermark. Used as the splash screen base layer. | `civic-empire-splash` |

All assets are hosted on the Manus CDN and tied to the project lifecycle. They are referenced by URL directly in the code — no local asset files.

---

## Phase 4 — Core Game Engine (`/client/src/lib/gameEngine.ts`)

The game engine is a pure TypeScript module with no external dependencies. It is entirely state-driven and designed to work with React's `useReducer` pattern.

### Data Structures

**`PlayerStats`**
```
health, happiness, money, reputation, corruption, age,
careerTier (1–5), currentJob, daysWorked
```

**`CityStats`**
```
employment, inflation, housingAffordability, crime,
population, cityTrust, currencyValue
```

**`Property`**
```
id, name, type, purchasePrice, currentValue,
monthlyIncome, maintenanceLevel, lastMaintained
```

**`GameEvent` / `EventOption`**
The event system supports three-choice decision events. Each option can have:
- Immediate effects on player stats and city stats
- Delayed effects that trigger after a specified number of in-game days (the Butterfly Effect system)
- A news headline that appears in the City Chronicle when the delayed effect fires

**`DelayedEffect`**
Stored in the game state array. Each tick checks if `triggerDay <= currentDay` and fires the effect if so.

### Key Engine Functions

| Function | Purpose |
| :--- | :--- |
| `tickGame(state, elapsedMs)` | Main game loop tick. Converts real milliseconds to fractional game days. Calls `processDayTick` for each full day elapsed. |
| `processDayTick(state)` | Processes one full in-game day: salary payment, property income (monthly), delayed effect resolution, city drift, event triggering. |
| `applyCityDrift(city, player)` | Applies slow natural economic drift every 7 days based on current stat levels. |
| `applyEventChoice(state, event, optionId)` | Resolves a player decision, applies immediate effects, queues delayed effects, and unpauses the game. |
| `buyProperty(state, propertyId)` | Deducts purchase price and adds property to portfolio. |
| `maintainProperty(state, propertyId)` | Costs $200, restores maintenanceLevel to 100, resets lastMaintained day. |
| `formatMoney(amount)` | Formats numbers as $2.5K, $1.2M etc. |
| `formatDay(gameDay)` | Converts a fractional game day number into `{ day, month, year }`. |

### Time Scale

- **1× speed:** 300,000ms real time = 1 in-game day
- **3× speed:** 100,000ms real time = 1 in-game day
- **1 in-game year:** 365 days
- **Auto-pause:** On event pop-ups and when the player manually pauses

### Economic Drift Rules (every 7 days)

- Employment > 80 → Inflation +0.3
- Inflation > 65 → City Trust −0.5
- Crime > 50 → City Trust −0.3, Population −50
- City Trust > 60 → Population +30
- Housing Affordability < 40 → City Trust −0.4

---

## Phase 5 — State Management (`/client/src/contexts/GameContext.tsx`)

A React Context + `useReducer` pattern manages all game state globally. The context provides:

- `state` — the full `GameState` object
- `dispatch` — the action dispatcher
- `saveNow` — a manual save trigger

### Game Actions

```
TICK, SET_PAUSED, SET_SPEED, SET_SCREEN, SET_BROWSER_TAB,
RESOLVE_EVENT, BUY_PROPERTY, MAINTAIN_PROPERTY,
SET_PLAYER_NAME, LOAD_SAVE
```

### Autosave

- Saves to `localStorage` under the key `civic_empire_save_v1` every 30 seconds via the `requestAnimationFrame` game loop.
- Also saves on screen transition (splash → game).
- On load, attempts to restore from `localStorage`. If the save is invalid or missing, falls back to `INITIAL_STATE`.

---

## Phase 6 — UI Architecture

### Layout Structure

```
<App>
  └── <GameProvider>
       ├── <SplashScreen>          (currentScreen === 'splash')
       └── <GameLayout>            (currentScreen === 'game')
            ├── Top HUD Bar        (logo, date, day bar, speed, pause, balance)
            ├── <TickerBar>        (scrolling news headlines)
            ├── Main Area
            │    ├── <CityMapView> (always visible — city background + 4 corner chips)
            │    ├── Stats Drawer  (slides in from left — <PlayerSidebar>)
            │    └── Browser Drawer(slides in from right — <FakeBrowser>)
            ├── Bottom Action Bar  (2 big + 6 quick buttons)
            ├── <EventModal>       (decision overlay, auto-pauses)
            └── <ReputationNotification> (milestone pop-up)
```

### Top HUD Bar

Contains only: logo, game title, date display, day-progress bar, 1×/3× speed toggle, pause/play button, and current balance. Deliberately minimal — no navigation buttons.

### Bottom Action Bar

The primary navigation layer. Two large anchor buttons on the left (Statistics) and right (City Net), with six quick-access shortcut buttons between them:

| Position | Button | Action |
| :--- | :--- | :--- |
| Far Left (large) | 📊 Statistics | Opens/closes the player stats drawer |
| 1 | 📰 News | Opens browser → News tab |
| 2 | 💼 Work | Opens browser → Work tab |
| 3 | 🔍 Jobs | Opens browser → Jobs tab |
| 4 | 🏠 Property | Opens browser → Real Estate tab |
| 5 | 🏦 Bank | Opens browser → Bank tab |
| 6 | 💬 Social | Opens browser → Social tab |
| Far Right (large) | 🌐 City Net | Opens/closes the browser drawer |

### Drawer Behaviour

Both drawers slide in with a 300ms `cubic-bezier(0.23, 1, 0.32, 1)` ease-out transition. A semi-transparent backdrop appears behind the active drawer and dismisses it on tap. Only one drawer can be open at a time.

---

## Phase 7 — The Fake Internet Browser (`<FakeBrowser>`)

The browser is the primary interaction layer for the game world. It mimics a real browser with:

- A **tab bar** showing 4 primary tabs (Work, CityBank, News, PropCity)
- A **URL bar** with a padlock icon, `https://` prefix, and the current site's address
- A **quick-links row** below the URL bar for fast navigation to secondary sites

### Websites Available

| Site | URL | Purpose |
| :--- | :--- | :--- |
| Work Desk | `cityworks.ce/dashboard` | Job mini-game — approve/deny applications |
| CityBank | `citybank.ce/account` | Balance, income breakdown, loans |
| City Chronicle | `citychronicle.ce/home` | News articles generated from game events |
| PropCity | `propcity.ce/listings` | Buy properties, manage maintenance |
| CityJobs | `cityjobs.ce/listings` | Career listings gated by reputation |
| CivicFeed | `civicfeed.ce/home` | Simulated social media reflecting city stats |
| InvestCE | `investce.ce/broker` | Stock market with 8 investment options |
| CityData | `citydata.ce/statistics` | Dedicated city statistics dashboard |

---

## Phase 8 — Individual Game Systems

### Work Mini-Game (`WorkTab`)

The Stage 1 job (Office Administrator) presents a queue of permit and grant applications. The player reviews each one and chooses to **Approve** or **Deny**.

- Each action dispatches a `RESOLVE_EVENT` action to the game engine, applying the reputation and money reward directly to player stats.
- Applications have three risk levels (Low, Medium, High) and include advisory notes for high-risk decisions.
- Some applications have delayed consequences (e.g., approving a poorly documented permit causes a news story and city stat change 45–120 days later).
- Currently 5 application types cycle in order. More variety is planned.

### Property System (`RealEstateTab`)

Three starter properties are available for purchase:

| Property | Price | Monthly Income |
| :--- | :--- | :--- |
| Studio Apartment — Eastside | $45,000 | $650 |
| 2-Bed House — Northgate | $120,000 | $1,400 |
| Corner Shop — Market District | $85,000 | $1,800 |

- Properties are purchased outright (no mortgage in the engine yet — bank loans are separate).
- Maintenance costs $200 per service and resets condition to 100%.
- Condition decays by 2 points per 30 days of neglect.
- Income is multiplied by `0.7 + (maintenanceLevel / 100) * 0.3` — a fully maintained property earns full income; a completely neglected one earns 70%.
- Property values are recalculated monthly based on city employment levels.

### Bank System (`BankTab`)

Provides a financial overview including:
- Current balance
- Monthly income breakdown (salary + property income)
- Active loan summary with repayment buttons

**Loan Options:**

| Loan | Amount | Rate | Term |
| :--- | :--- | :--- | :--- |
| Personal Loan | $5,000 | 8.5% | 12 months |
| Home Improvement | $15,000 | 7.2% | 24 months |
| Business Loan | $50,000 | 9.8% | 36 months |
| Property Mortgage | $100,000 | 6.5% | 60 months |

> **Known Issue:** Loan money is not yet wired into the game engine's player balance. The UI shows the loan as approved and tracks repayments locally, but the balance does not increase. This requires a dedicated `TAKE_LOAN` action in the game reducer.

### Stock Market (`StocksTab`)

Eight stocks are available across six sectors. Prices fluctuate every 10 seconds via a `setInterval` in the component (independent of the game engine clock — this is a known simplification).

| Ticker | Company | Sector | Risk |
| :--- | :--- | :--- | :--- |
| CBC | CityBank Corp | Finance | Low |
| HPT | Hartfield Property | Real Estate | Medium |
| NTL | NovaTech Logistics | Technology | Medium |
| CPG | City Power Grid | Utilities | Low |
| ERC | Eastside Retail Co. | Retail | High |
| CBI | CivicBuild Infra | Construction | Medium |
| MTL | Metro Transit Ltd | Transport | Low |
| ACF | Apex Capital Fund | Finance | High |

> **Known Issue:** Stock purchases deduct money via a workaround rather than a proper engine action. Holdings are stored in local component state, not in the global game state, meaning they do not persist across sessions. This needs to be moved into the game engine.

### Career System (`JobsTab`)

Job listings are gated by reputation thresholds:

| Tier | Jobs Available | Reputation Required |
| :--- | :--- | :--- |
| 1 | Office Administrator | 0 |
| 2 | Property Inspector, Tax Clerk | 100 |
| 3 | Treasury Officer, Trade Commissioner | 300 |
| 4+ | Offered, not applied for | 600+ |

Applying for a job currently shows a toast confirmation. The actual job change mechanic (updating `player.currentJob` and `player.careerTier`) is not yet implemented in the engine.

### City Statistics (`CityStatsTab`)

A dedicated website displaying all six city variables with colour-coded health indicators, progress bars, and plain-language descriptions. Also shows the key economic relationships (e.g., high employment → lower crime → higher trust).

### Social Media (`SocialTab`)

CivicFeed generates posts dynamically based on current city stat values. Posts are positive or negative depending on whether employment, inflation, crime, housing, and trust are above or below thresholds. This creates the "perception vs. reality" mechanic — the feed reflects what citizens believe, not necessarily the raw numbers.

### Event Decision System (`EventModal`)

When a random event fires, time auto-pauses and a cinematic modal slides up from the bottom. The player chooses from three preset options. Each option:
- Applies immediate effects to player and/or city stats
- May queue delayed effects (the Butterfly Effect)
- May generate a future news headline

The modal dismisses and time resumes after a choice is made.

### Reputation Milestone Notifications (`ReputationNotification`)

Watches `player.reputation` for threshold crossings (100, 300, 600, 900). When a threshold is crossed for the first time, a notification slides up from the bottom of the screen with the milestone, the unlocked career tier name, and a prompt to visit CityJobs. Auto-dismisses after 5 seconds.

---

## Phase 9 — Orientation & Mobile

The game was originally built with a forced landscape orientation check using `window.screen.orientation`. This caused issues on some Android browsers where the orientation API reported incorrect values.

**Resolution:**
- Switched to `window.innerWidth > window.innerHeight` as the primary detection method (most reliable cross-browser).
- Added a 100ms delay after `orientationchange` events to allow the browser to finish repainting before dimensions are read.
- Added a **"Continue Anyway"** button to the rotate prompt so players are never permanently stuck.
- **Final decision:** Orientation forcing was removed entirely at the developer's request. The game works in any orientation; the rotate prompt is gone.

---

## Known Issues & Planned Work

### High Priority

| Issue | Description |
| :--- | :--- |
| **Bank loans not wired** | Loan approval does not add money to player balance. Needs `TAKE_LOAN` action in game reducer. |
| **Stock holdings not persisted** | Holdings live in component state, not game state. Lost on refresh. |
| **Job change not implemented** | Applying for a job shows a toast but does not change `player.currentJob` or `player.careerTier`. |

### Medium Priority

| Item | Description |
| :--- | :--- |
| **More work events** | Currently 5 application types cycle. Need 15–20 for variety. |
| **New Game / Continue screen** | Splash should detect a localStorage save and offer "Continue" vs "New Game". |
| **Stage 2 work mini-game** | Property Inspector role needs its own mini-game (e.g., flagging compliance issues). |
| **Election system** | Not yet implemented. Required for the win condition. |

### Low Priority / Future

| Item | Description |
| :--- | :--- |
| Corruption investigation events | Triggered when `player.corruption` exceeds thresholds |
| Lobby group pressure events | Groups apply pressure based on policy decisions |
| Business ownership system | Player can start and manage businesses |
| Stage 3–5 career content | Economic authority, political campaign, and city leader systems |
| Sound effects | Ambient city sounds, UI feedback sounds |
| Animated city map | Moving elements on the map background to indicate city activity |

---

## File Structure Reference

```
civic-empire/
├── client/
│   ├── index.html                          ← Fonts (Playfair Display, IBM Plex Sans/Mono)
│   └── src/
│       ├── App.tsx                         ← Root: GameProvider + GameRouter
│       ├── index.css                       ← Global theme, custom animations, game utilities
│       ├── lib/
│       │   └── gameEngine.ts               ← Core game logic, all types, state, tick functions
│       ├── contexts/
│       │   ├── GameContext.tsx             ← useReducer state, game loop, autosave
│       │   └── ThemeContext.tsx            ← Dark theme provider
│       ├── hooks/
│       │   └── useOrientation.ts           ← Landscape/portrait detection (deprecated)
│       └── components/
│           └── game/
│               ├── SplashScreen.tsx        ← Entry screen with name input
│               ├── GameLayout.tsx          ← Main game shell: HUD + ticker + drawers + bottom bar
│               ├── TickerBar.tsx           ← Scrolling news headline ticker
│               ├── PlayerSidebar.tsx       ← Player stats drawer (left)
│               ├── CityMapView.tsx         ← Central map area with 4 corner stat chips
│               ├── FakeBrowser.tsx         ← Browser chrome: tabs, URL bar, quick links
│               ├── EventModal.tsx          ← Decision overlay modal
│               ├── ReputationNotification.tsx ← Milestone pop-up
│               └── browser-tabs/
│                   ├── NewsTab.tsx         ← The City Chronicle
│                   ├── WorkTab.tsx         ← Office Administrator mini-game
│                   ├── JobsTab.tsx         ← CityJobs career portal
│                   ├── RealEstateTab.tsx   ← PropCity property listings
│                   ├── BankTab.tsx         ← CityBank account + loans
│                   ├── SocialTab.tsx       ← CivicFeed social media
│                   ├── StocksTab.tsx       ← InvestCE stock broker
│                   └── CityStatsTab.tsx    ← CityData statistics portal
├── ideas.md                                ← Design brainstorm and chosen direction
└── Civic_Empire_Master_Design_Summary.md  ← (in /home/ubuntu/)
└── Civic_Empire_Core_Concept.md           ← (in /home/ubuntu/)
```

---

## Checkpoint History

| Version | Description |
| :--- | :--- |
| `e1afcaa8` | Initial project scaffold |
| `3850e9dd` | MVP v0.1 — First playable build with all core systems |
| `2b6def77` | v0.2 — Mobile landscape UI with slide-in drawers |
| `9e13121b` | v0.3 — Orientation detection fix + "Continue Anyway" button |
| `54d81a2c` | v0.4 — Bottom action bar, stocks, city stats site, bank loans, autosave, rep notifications |

---

*Dev Log maintained by Manus AI. Last updated: June 2026.*
