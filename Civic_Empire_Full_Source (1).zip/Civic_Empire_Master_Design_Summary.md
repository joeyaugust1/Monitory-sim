# Master Design Summary: Civic Empire

## 1. Overview
**Civic Empire** is a single-player 2D strategy, political, economic, and life simulation game. The player begins as an ordinary citizen with little money, influence, or power. Through employment, business ownership, property investment, political involvement, and economic decision-making, the player gradually climbs the city's power structure.

The ultimate objective is to reach the highest leadership position in the city and successfully maintain that position through two consecutive election terms.

The game combines:
*   Economic and political simulation
*   Property and business management
*   Career progression and public opinion management
*   Long-term strategic planning

## 2. Core Gameplay Philosophy
The game is not intended to be a perfect simulation of a real-world economy. Instead, it creates believable cause-and-effect relationships that are easy for players to understand while offering significant strategic depth.

The player constantly faces trade-offs. Every major decision creates winners and losers.
*   *Example:* Higher wages improve public happiness but reduce business profits.
*   *Example:* Lower taxes increase popularity but reduce city revenue.

### 2.1 The Butterfly Effect System
A core design principle. Every significant decision has immediate consequences, long-term consequences, positive effects, and negative effects. There is rarely a perfect choice.
*   *Example:* Cutting education funding creates an immediate budget surplus, but three years later results in fewer skilled workers, lower productivity, and rising unemployment.

## 3. Game State & Progression

### 3.1 Time Progression
Time progresses continuously in real-time. 
*   **Scale:** 5 minutes of real-world time equals 1 in-game day (24 hours).
*   **Controls:** The time is displayed in the top-left corner. Players can pause time, run at normal speed, or speed up time (3x). Time automatically pauses during pop-up events or critical decisions.

### 3.2 Player Stats
The player manages four personal statistics:
*   **Health:** Decreases if overworked or stressed; requires rest/medical care.
*   **Happiness:** Affected by wealth, housing, and job satisfaction.
*   **Money:** Used for investments, property, and campaigning.
*   **Reputation:** The primary metric for career advancement and political influence.

### 3.3 Win & Loss Conditions
**Primary Objective:** Reach the highest leadership position (Mayor/Governor) and successfully complete two consecutive election terms.

**Failure Conditions:**
*   **Political:** Losing an election, removal from office, or public trust reaching zero.
*   **Economic:** Severe recession, hyperinflation, or bankruptcy.
*   **Social:** Uncontrollable crime or mass population decline.
*   **Personal:** Health reaching zero or criminal conviction (corruption scandals).

## 4. Career System & Progression Stages
Careers represent the path to power. Advancement is based on **Reputation**, which is earned by making good decisions during job mini-games and random events. Once enough reputation is gained, players apply for higher-tier jobs via the in-game job seekers website.

### Stage 1: Citizen
*   **Roles:** Basic jobs (e.g., Office Worker, Retail).
*   **Mechanics:** Working involves minimal, job-specific mini-games (e.g., approving/disapproving applications). Players buy property, save money, and build initial reputation. Cannot influence city systems.

### Stage 2: Local Influence
*   **Roles:** Property Inspector, Housing Officer, Tax Clerk.
*   **Mechanics:** Players begin affecting the local economy (e.g., property approvals, minor regulations).

### Stage 3: Economic Authority
*   **Roles:** Treasury Officer, Economic Analyst, Trade Commissioner.
*   **Mechanics:** Player gains control over macroeconomic levers: interest rates, import taxes, and business grants.

### Stage 4: Politics (Senior Authority)
*   **Roles:** Deputy Governor, Chief Advisor.
*   **Mechanics:** Player runs for office. They must navigate a campaign, give speeches, buy advertising, and win votes to secure the top position.

### Stage 5: City Leader
*   **Roles:** Mayor / Governor.
*   **Mechanics:** Controls almost everything—taxes, public spending, infrastructure, and trade policy. The highest level of power.

## 5. Main Game Systems

### 5.1 The Economy & Core Variables
The city tracks six major statistics that dictate the state of the simulation:
1.  **Employment:** High employment boosts spending and trust; low employment increases crime.
2.  **Inflation:** Moderate is healthy. High inflation hurts citizens; deflation hurts businesses.
3.  **Housing Affordability:** Must be balanced between investor profits and citizen happiness.
4.  **Population:** Grows with jobs and housing; declines with crime and weak economy.
5.  **Crime:** Lowers property values and election support.
6.  **City Trust:** The most critical stat. Influences elections, investment, and resilience.

### 5.2 The Currency System (City Dollar - $)
The currency has a value score (e.g., 100 = Stable).
*   **Strong Currency (>100):** Cheaper imports, lower inflation, but less competitive exports (hurts manufacturing).
*   **Weak Currency (<100):** Increased exports and tourism, but expensive imports and rising inflation.

### 5.3 Property System
Properties serve as long-term investments and generate income (rent, sales, profit).
*   **Active Maintenance:** Properties must be actively maintained. Maintenance costs money; neglecting it causes the property to lose value over time.
*   **Types:** Houses, Apartments, Shops, Offices, Factories. Property values fluctuate based on crime, employment, and interest rates.

### 5.4 Business System
Businesses create jobs and wealth. Players can manage businesses (e.g., raising/lowering wages, advertising, expanding). Decisions impact profit, reputation, and employee satisfaction.

### 5.5 Event & Decision System
While playing and working, events will initiate a decision. Players must choose between 3 preset options. These decisions have flow-on effects (Butterfly Effect).
*   *Random Events:* Housing crashes, tech booms, droughts, strikes.

### 5.6 Corruption System (Hidden Mechanic)
Players may secretly accept donations, favor businesses, or manipulate contracts.
*   **Benefits:** Faster growth, more money/influence.
*   **Risks:** If investigated and exposed, trust crashes, elections are lost, and it may result in a Game Over.

## 6. UI & The "Fake Internet"
The game UI is split into two main concepts:
1.  **Main Screen:** City map, buildings, businesses, citizens, and time progression.
2.  **Secondary Screen (Simulated Internet):** A fake internet interface where players access information.
    *   *Websites:* News sites, social media, job seekers, real estate listings, bank portals, and election polls.
    *   *Purpose:* Instead of viewing raw spreadsheets, players learn about the city naturally. (e.g., Seeing a news headline "Housing Prices Reach Record High" instead of just seeing a stat increase).

## 7. Public Sentiment & Lobby Groups
Citizens react to what they *believe* is happening. Reality and perception can differ (e.g., if the economy is weakening but media coverage is positive, public trust may remain temporarily high).
*   **Lobby Groups:** Homeowners, Renters, Banks, Trade Unions. Every policy affects these groups differently. Supporting one often harms another.

## 8. Technology Stack
*   **Languages:** HTML, CSS, JavaScript
*   **Format:** Browser-based (Mobile-friendly, easily hosted via GitHub Pages). No installation required.
