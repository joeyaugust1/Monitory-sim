// ============================================================
// CIVIC EMPIRE — App Root
// ============================================================

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./contexts/ThemeContext";
import { GameProvider, useGame } from "./contexts/GameContext";
import SplashScreen from "./components/game/SplashScreen";
import GameLayout from "./components/game/GameLayout";
import ErrorBoundary from "./components/ErrorBoundary";

function GameRouter() {
  const { state } = useGame();
  if (state.currentScreen === 'splash') return <SplashScreen />;
  return <GameLayout />;
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            toastOptions={{
              style: {
                background: '#1a1f2e',
                border: '1px solid rgba(255,255,255,0.1)',
                color: '#e8e6e1',
              },
            }}
          />
          <GameProvider>
            <GameRouter />
          </GameProvider>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
