// ============================================================
// CIVIC EMPIRE — City Map View
// Central game area — the city the player is trying to control
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { getStatColor } from '@/lib/gameEngine';

const CITY_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-city-bg-npdx9GBWGg8sGciM9JyXgG.webp';

export default function CityMapView() {
  const { state } = useGame();
  const { city, player, isPaused } = state;

  return (
    <div
      className="absolute inset-0 flex flex-col items-center justify-center overflow-hidden"
      style={{ backgroundImage: `url(${CITY_BG})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-[#0a0c12]/75" />

      {/* Subtle grid overlay */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `
            linear-gradient(rgba(212,160,23,0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(212,160,23,0.5) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* Centre content */}
      <div className="relative z-10 text-center px-6">
        {isPaused ? (
          <div className="text-amber-400/60 font-mono text-xs uppercase tracking-widest animate-pulse mb-2">
            ⏸ Paused
          </div>
        ) : (
          <div className="text-white/20 font-mono text-[10px] uppercase tracking-widest mb-2">
            City is running
          </div>
        )}

        <h2 className="text-white/15 font-serif text-4xl font-bold mb-1 select-none">
          Civic Empire
        </h2>
        <p className="text-white/10 font-sans text-xs">
          Population {city.population.toLocaleString()}
        </p>
      </div>

      {/* Minimal corner indicators — tap City Stats for full detail */}
      <div className="absolute bottom-3 left-3 flex gap-1.5">
        <StatChip label="Trust" value={city.cityTrust} inverse={false} />
        <StatChip label="Crime" value={city.crime} inverse={true} />
      </div>
      <div className="absolute bottom-3 right-3 flex gap-1.5">
        <StatChip label="Jobs" value={city.employment} inverse={false} />
        <StatChip label="Housing" value={city.housingAffordability} inverse={false} />
      </div>

      {/* Hint text */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 text-white/15 text-[10px] font-mono uppercase tracking-widest whitespace-nowrap">
        Tap Statistics or City Net to manage your empire
      </div>
    </div>
  );
}

function StatChip({ label, value, inverse }: { label: string; value: number; inverse: boolean }) {
  const colorClass = inverse
    ? value > 60 ? 'text-red-400' : value < 40 ? 'text-emerald-400' : 'text-amber-400'
    : value > 60 ? 'text-emerald-400' : value < 40 ? 'text-red-400' : 'text-amber-400';

  return (
    <div className="flex items-center gap-1.5 bg-black/50 border border-white/10 rounded px-2 py-1 backdrop-blur-sm">
      <span className="text-white/30 text-[9px] font-mono uppercase">{label}</span>
      <span className={`font-mono text-[10px] font-medium ${colorClass}`}>{Math.round(value)}%</span>
    </div>
  );
}
