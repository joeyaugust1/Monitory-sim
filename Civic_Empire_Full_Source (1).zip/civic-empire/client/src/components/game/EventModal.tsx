// ============================================================
// CIVIC EMPIRE — Event Decision Modal
// Cinematic decision overlay — auto-pauses time
// Players choose between 3 preset options
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { GameEvent } from '@/lib/gameEngine';

export default function EventModal() {
  const { state, dispatch } = useGame();
  const { pendingEvents } = state;

  if (pendingEvents.length === 0) return null;

  const event = pendingEvents[0];

  const handleChoice = (optionId: string) => {
    dispatch({ type: 'RESOLVE_EVENT', event, optionId });
  };

  const categoryColors: Record<string, string> = {
    work: 'text-sky-400 bg-sky-400/10 border-sky-400/20',
    city: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
    personal: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
    political: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="decision-modal w-full max-w-2xl bg-[#1a1f2e] border border-white/12 rounded-xl overflow-hidden shadow-2xl mb-4">

        {/* Modal Header */}
        <div className="bg-[#0f1117] px-6 py-4 border-b border-white/8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-white/40 text-[10px] font-mono uppercase tracking-widest">Decision Required</span>
          </div>
          <span className={`text-[10px] font-mono uppercase tracking-widest px-2 py-1 rounded border ${categoryColors[event.category] || categoryColors.city}`}>
            {event.category}
          </span>
        </div>

        {/* Event Content */}
        <div className="px-6 py-5">
          <h2 className="text-white font-serif text-xl font-bold mb-3">{event.title}</h2>
          <p className="text-white/60 text-sm font-sans leading-relaxed">{event.description}</p>
        </div>

        {/* Options */}
        <div className="px-6 pb-6 space-y-2">
          <div className="text-white/30 text-[10px] font-mono uppercase tracking-widest mb-3">Choose your response:</div>
          {event.options.map((option, i) => (
            <button
              key={option.id}
              onClick={() => handleChoice(option.id)}
              className="w-full text-left border border-white/10 bg-white/3 hover:bg-white/8 hover:border-amber-400/30 rounded-lg p-4 transition-all duration-150 active:scale-[0.99] group"
            >
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded border border-white/15 bg-white/5 flex items-center justify-center text-white/40 text-xs font-mono flex-shrink-0 group-hover:border-amber-400/40 group-hover:text-amber-400 transition-colors">
                  {String.fromCharCode(65 + i)}
                </span>
                <div>
                  <div className="text-white/85 font-sans text-sm font-medium mb-0.5 group-hover:text-white transition-colors">
                    {option.label}
                  </div>
                  <div className="text-white/40 text-xs font-sans leading-relaxed">
                    {option.description}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="px-6 pb-4">
          <div className="text-white/20 text-[10px] font-sans text-center">
            Time is paused. Your decision will have consequences — some immediate, some delayed.
          </div>
        </div>
      </div>
    </div>
  );
}
