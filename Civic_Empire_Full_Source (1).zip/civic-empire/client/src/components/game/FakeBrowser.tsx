// ============================================================
// CIVIC EMPIRE — Fake Internet Browser
// 4 tabs, URL bar with quick-link shortcuts below it
// ============================================================

import { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import NewsTab from './browser-tabs/NewsTab';
import JobsTab from './browser-tabs/JobsTab';
import RealEstateTab from './browser-tabs/RealEstateTab';
import BankTab from './browser-tabs/BankTab';
import SocialTab from './browser-tabs/SocialTab';
import WorkTab from './browser-tabs/WorkTab';
import StocksTab from './browser-tabs/StocksTab';
import CityStatsTab from './browser-tabs/CityStatsTab';

// Only 4 primary tabs shown in the tab bar
const PRIMARY_TABS: Array<{ id: string; label: string; icon: string }> = [
  { id: 'work',       label: 'Work',     icon: '💼' },
  { id: 'bank',       label: 'CityBank', icon: '🏦' },
  { id: 'news',       label: 'News',     icon: '📰' },
  { id: 'realestate', label: 'PropCity', icon: '🏠' },
];

// Quick-link shortcuts shown below the URL bar
const QUICK_LINKS: Array<{ id: string; label: string; icon: string; url: string }> = [
  { id: 'jobs',      label: 'CityJobs',    icon: '🔍', url: 'cityjobs.ce/listings' },
  { id: 'social',    label: 'CivicFeed',   icon: '💬', url: 'civicfeed.ce/home' },
  { id: 'stocks',    label: 'InvestCE',    icon: '📈', url: 'investce.ce/broker' },
  { id: 'citystats', label: 'City Stats',  icon: '🏙️', url: 'citydata.ce/statistics' },
];

const TAB_URLS: Record<string, string> = {
  work:       'cityworks.ce/dashboard',
  bank:       'citybank.ce/account',
  news:       'citychronicle.ce/home',
  realestate: 'propcity.ce/listings',
  jobs:       'cityjobs.ce/listings',
  social:     'civicfeed.ce/home',
  stocks:     'investce.ce/broker',
  citystats:  'citydata.ce/statistics',
};

export default function FakeBrowser() {
  const { state, dispatch } = useGame();
  const [urlInput, setUrlInput] = useState('');
  const activeTab = state.activeBrowserTab;

  const setTab = (tab: string) => {
    dispatch({ type: 'SET_BROWSER_TAB', tab: tab as any });
    setUrlInput('');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'news':       return <NewsTab />;
      case 'work':       return <WorkTab />;
      case 'jobs':       return <JobsTab />;
      case 'realestate': return <RealEstateTab />;
      case 'bank':       return <BankTab />;
      case 'social':     return <SocialTab />;
      case 'stocks':     return <StocksTab />;
      case 'citystats':  return <CityStatsTab />;
      default:           return <NewsTab />;
    }
  };

  const currentUrl = TAB_URLS[activeTab] || 'citychronicle.ce/home';

  return (
    <div className="flex flex-col h-full bg-[#0f1117]">

      {/* ── TAB BAR (4 primary tabs) ── */}
      <div className="flex-shrink-0 bg-[#0a0c12] border-b border-white/8 flex items-end pt-1.5 px-2 gap-0.5 overflow-x-auto">
        {PRIMARY_TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans rounded-t border-t border-l border-r transition-all duration-150 whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-[#0f1117] border-white/10 text-white/90'
                : 'bg-transparent border-transparent text-white/30 hover:text-white/60 hover:bg-white/4'
            }`}
          >
            <span className="text-[11px]">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
        {/* Show active tab label if it's not in primary tabs */}
        {!PRIMARY_TABS.find(t => t.id === activeTab) && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans rounded-t border-t border-l border-r bg-[#0f1117] border-white/10 text-white/90 whitespace-nowrap">
            <span>{QUICK_LINKS.find(l => l.id === activeTab)?.icon}</span>
            <span>{QUICK_LINKS.find(l => l.id === activeTab)?.label}</span>
          </div>
        )}
      </div>

      {/* ── URL BAR ── */}
      <div className="flex-shrink-0 bg-[#0d0f18] border-b border-white/6 px-2 py-1.5 flex items-center gap-2">
        <div className="flex gap-1 flex-shrink-0">
          <div className="w-2 h-2 rounded-full bg-red-500/50" />
          <div className="w-2 h-2 rounded-full bg-amber-500/50" />
          <div className="w-2 h-2 rounded-full bg-emerald-500/50" />
        </div>
        <div className="flex-1 bg-white/5 border border-white/8 rounded px-2 py-1 flex items-center gap-1.5">
          <span className="text-emerald-400 text-[9px]">🔒</span>
          <span className="text-white/30 font-mono text-[10px]">https://</span>
          <input
            type="text"
            value={urlInput || currentUrl}
            onChange={e => setUrlInput(e.target.value)}
            onFocus={e => { setUrlInput(currentUrl); e.target.select(); }}
            onBlur={() => setUrlInput('')}
            className="flex-1 bg-transparent text-white/70 font-mono text-[10px] outline-none min-w-0"
          />
        </div>
      </div>

      {/* ── QUICK LINKS (below URL bar) ── */}
      <div className="flex-shrink-0 bg-[#0d0f18] border-b border-white/6 px-2 py-1.5 flex items-center gap-1.5 overflow-x-auto">
        <span className="text-white/20 text-[9px] font-mono uppercase flex-shrink-0 mr-1">Quick:</span>
        {QUICK_LINKS.map(link => (
          <button
            key={link.id}
            onClick={() => setTab(link.id)}
            className={`flex items-center gap-1 px-2 py-1 rounded border text-[10px] font-sans whitespace-nowrap transition-all duration-150 active:scale-95 flex-shrink-0 ${
              activeTab === link.id
                ? 'bg-amber-400/15 border-amber-400/30 text-amber-400'
                : 'bg-white/4 border-white/8 text-white/40 hover:bg-white/8 hover:text-white/70'
            }`}
          >
            <span>{link.icon}</span>
            <span>{link.label}</span>
          </button>
        ))}
      </div>

      {/* ── PAGE CONTENT ── */}
      <div className="flex-1 overflow-y-auto">
        {renderContent()}
      </div>
    </div>
  );
}
