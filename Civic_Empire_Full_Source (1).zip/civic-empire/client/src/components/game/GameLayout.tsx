// ============================================================
// CIVIC EMPIRE — Game Layout (Mobile-first, no forced rotation)
// Top HUD: time/date/pause/speed only
// Bottom bar: 2 big buttons + 6 quick-access buttons
// ============================================================

import { useState, useEffect, useRef } from 'react';
import { useGame } from '@/contexts/GameContext';
import TickerBar from './TickerBar';
import PlayerSidebar from './PlayerSidebar';
import FakeBrowser from './FakeBrowser';
import EventModal from './EventModal';
import CityMapView from './CityMapView';
import ReputationNotification from './ReputationNotification';
import { formatMoney, formatDay } from '@/lib/gameEngine';

const LOGO = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-logo-SurMiAjwNwdtv3HydJ4ina.webp';

const QUICK_BUTTONS = [
  { id: 'news',       icon: '📰', label: 'News',    tab: 'news' },
  { id: 'work',       icon: '💼', label: 'Work',    tab: 'work' },
  { id: 'jobs',       icon: '🔍', label: 'Jobs',    tab: 'jobs' },
  { id: 'realestate', icon: '🏠', label: 'Property',tab: 'realestate' },
  { id: 'bank',       icon: '🏦', label: 'Bank',    tab: 'bank' },
  { id: 'social',     icon: '💬', label: 'Social',  tab: 'social' },
];

export default function GameLayout() {
  const { state, dispatch } = useGame();
  const [statsOpen, setStatsOpen] = useState(false);
  const [browserOpen, setBrowserOpen] = useState(false);

  const { player, isPaused, timeSpeed, gameDay } = state;
  const { day, month, year } = formatDay(gameDay);
  const dayProgress = (gameDay % 1) * 100;

  const closeAll = () => {
    setStatsOpen(false);
    setBrowserOpen(false);
  };

  const openBrowserTab = (tab: string) => {
    dispatch({ type: 'SET_BROWSER_TAB', tab: tab as any });
    setBrowserOpen(true);
    setStatsOpen(false);
  };

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0a0c12] overflow-hidden">

      {/* ── TOP HUD BAR ── */}
      <div className="flex-shrink-0 h-10 bg-[#0a0c12] border-b border-white/8 flex items-center px-3 gap-2 z-30">
        {/* Logo */}
        <img src={LOGO} alt="" className="w-6 h-6 object-contain flex-shrink-0" />
        <span className="text-amber-400 font-serif text-sm font-bold tracking-wide flex-shrink-0">Civic Empire</span>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Day progress bar + date */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="flex flex-col items-end gap-0.5">
            <span className="text-amber-400 font-mono text-[10px] leading-none">{month} {day}, Yr {year}</span>
            <div className="w-20 h-1 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-amber-400 rounded-full transition-all duration-100" style={{ width: `${dayProgress}%` }} />
            </div>
          </div>
        </div>

        {/* Speed */}
        <button
          onClick={() => dispatch({ type: 'SET_SPEED', speed: timeSpeed === 1 ? 3 : 1 })}
          className={`px-2 h-7 text-xs font-mono rounded border transition-all duration-150 active:scale-95 flex-shrink-0 ${
            timeSpeed === 3 ? 'bg-teal-500/20 text-teal-400 border-teal-500/40' : 'bg-white/5 text-white/40 border-white/10 hover:bg-white/10'
          }`}
        >
          {timeSpeed === 3 ? '3×' : '1×'}
        </button>

        {/* Pause */}
        <button
          onClick={() => dispatch({ type: 'SET_PAUSED', paused: !isPaused })}
          className={`px-3 h-7 text-xs font-mono rounded border transition-all duration-150 active:scale-95 flex-shrink-0 ${
            isPaused ? 'bg-amber-400 text-black border-amber-400 font-semibold' : 'bg-white/5 text-white/60 border-white/10 hover:bg-white/10'
          }`}
        >
          {isPaused ? '▶' : '⏸'}
        </button>

        {/* Balance */}
        <div className="px-2 h-7 flex items-center bg-white/4 border border-white/8 rounded flex-shrink-0">
          <span className="text-amber-400 font-mono text-xs">{formatMoney(player.money)}</span>
        </div>
      </div>

      {/* ── TICKER BAR ── */}
      <TickerBar />

      {/* ── MAIN AREA ── */}
      <div className="flex-1 relative overflow-hidden">

        {/* Central Map — always visible */}
        <CityMapView />

        {/* ── STATS DRAWER (slides in from left) ── */}
        <div
          className={`absolute top-0 left-0 h-full z-20 transition-transform duration-300 ease-[cubic-bezier(0.23,1,0.32,1)] ${statsOpen ? 'translate-x-0' : '-translate-x-full'}`}
          style={{ width: 'min(320px, 92vw)' }}
        >
          <PlayerSidebar onClose={() => setStatsOpen(false)} />
        </div>

        {/* ── BROWSER DRAWER (slides in from right) ── */}
        <div
          className={`absolute top-0 right-0 h-full z-20 transition-transform duration-300 ease-[cubic-bezier(0.23,1,0.32,1)] ${browserOpen ? 'translate-x-0' : 'translate-x-full'}`}
          style={{ width: 'min(480px, 100vw)' }}
        >
          <div className="h-full bg-[#0f1117] border-l border-white/10 flex flex-col overflow-hidden">
            <div className="flex-shrink-0 h-9 bg-[#0a0c12] border-b border-white/8 flex items-center justify-between px-3">
              <span className="text-amber-400 font-mono text-[10px] uppercase tracking-widest">City Internet</span>
              <button onClick={() => setBrowserOpen(false)} className="text-white/30 hover:text-white/70 text-xl leading-none transition-colors">×</button>
            </div>
            <div className="flex-1 overflow-hidden">
              <FakeBrowser />
            </div>
          </div>
        </div>

        {/* ── BACKDROP ── */}
        {(statsOpen || browserOpen) && (
          <div className="absolute inset-0 z-10 bg-black/40" onClick={closeAll} />
        )}
      </div>

      {/* ── BOTTOM ACTION BAR ── */}
      <div className="flex-shrink-0 bg-[#0a0c12] border-t border-white/8 px-2 py-2 z-30">
        <div className="flex items-center gap-2">

          {/* BIG BUTTON 1: Statistics */}
          <button
            onClick={() => { setStatsOpen(o => !o); setBrowserOpen(false); }}
            className={`flex flex-col items-center justify-center gap-0.5 h-14 w-20 flex-shrink-0 rounded-lg border text-center transition-all duration-150 active:scale-95 ${
              statsOpen ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/5 text-amber-400 border-amber-400/30 hover:bg-amber-400/10'
            }`}
          >
            <span className="text-lg leading-none">📊</span>
            <span className="text-[9px] font-mono uppercase tracking-widest leading-none">Statistics</span>
          </button>

          {/* 6 QUICK-ACCESS SMALL BUTTONS */}
          <div className="flex-1 grid grid-cols-6 gap-1">
            {QUICK_BUTTONS.map(btn => (
              <button
                key={btn.id}
                onClick={() => openBrowserTab(btn.tab)}
                className={`flex flex-col items-center justify-center gap-0.5 h-14 rounded border transition-all duration-150 active:scale-95 ${
                  state.activeBrowserTab === btn.id && browserOpen
                    ? 'bg-amber-400/15 border-amber-400/40 text-amber-400'
                    : 'bg-white/4 border-white/8 text-white/50 hover:bg-white/8 hover:text-white/80'
                }`}
              >
                <span className="text-base leading-none">{btn.icon}</span>
                <span className="text-[8px] font-mono uppercase tracking-wide leading-none">{btn.label}</span>
              </button>
            ))}
          </div>

          {/* BIG BUTTON 2: City Net (Web UI) */}
          <button
            onClick={() => { setBrowserOpen(o => !o); setStatsOpen(false); }}
            className={`flex flex-col items-center justify-center gap-0.5 h-14 w-20 flex-shrink-0 rounded-lg border text-center transition-all duration-150 active:scale-95 ${
              browserOpen ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/5 text-amber-400 border-amber-400/30 hover:bg-amber-400/10'
            }`}
          >
            <span className="text-lg leading-none">🌐</span>
            <span className="text-[9px] font-mono uppercase tracking-widest leading-none">City Net</span>
          </button>
        </div>
      </div>

      {/* ── EVENT MODAL ── */}
      <EventModal />

      {/* ── REPUTATION NOTIFICATION ── */}
      <ReputationNotification />
    </div>
  );
}
