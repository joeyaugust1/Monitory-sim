// ============================================================
// CIVIC EMPIRE — Player Sidebar
// Left panel: Player stats, time bar, city overview
// Design: Authority through restraint. Data as drama.
// ============================================================

import { useGame } from '@/contexts/GameContext';
import {
  formatMoney,
  formatDay,
  getCareerTitle,
  getReputationForNextTier,
} from '@/lib/gameEngine';

const LOGO_URL = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-logo-SurMiAjwNwdtv3HydJ4ina.webp';

interface PlayerSidebarProps {
  onClose?: () => void;
}

export default function PlayerSidebar({ onClose }: PlayerSidebarProps = {}) {
  const { state } = useGame();
  const { player, gameDay } = state;
  const { day, month, year } = formatDay(gameDay);

  const repNeeded = getReputationForNextTier(player.careerTier);
  const repProgress = Math.min(100, (player.reputation / repNeeded) * 100);
  const dayProgress = ((gameDay % 1)) * 100;

  return (
    <aside className="w-full h-full bg-[#0f1117] border-r border-white/10 flex flex-col overflow-y-auto">

      {/* Logo + Title + Close */}
      <div className="p-3 border-b border-white/8 flex items-center gap-3 flex-shrink-0">
        <img src={LOGO_URL} alt="Civic Empire" className="w-8 h-8 object-contain" />
        <div className="flex-1">
          <div className="text-amber-400 font-serif text-sm font-bold leading-tight tracking-wide">Statistics</div>
          <div className="text-white/30 text-[10px] font-mono uppercase tracking-widest">Player &amp; City</div>
        </div>
        {onClose && (
          <button onClick={onClose} className="text-white/30 hover:text-white/70 text-xl leading-none transition-colors ml-auto">
            ×
          </button>
        )}
      </div>

      {/* Time Bar */}
      <div className="px-4 pt-3 pb-3 border-b border-white/8">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-white/50 text-[10px] font-mono uppercase tracking-widest">Day Progress</span>
          <span className="text-amber-400 font-mono text-xs">{month} {day}, Year {year}</span>
        </div>
        <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
          <div
            className="h-full bg-amber-400 rounded-full transition-all duration-100"
            style={{ width: `${dayProgress}%` }}
          />
        </div>
      </div>

      {/* Player Stats */}
      <div className="p-4 border-b border-white/8">
        <div className="flex items-center justify-between mb-3">
          <span className="text-white/50 text-[10px] font-mono uppercase tracking-widest">Player</span>
          <span className="text-amber-400/70 text-[10px] font-mono">{getCareerTitle(player.careerTier)}</span>
        </div>

        <div className="text-white/90 font-sans text-sm font-semibold mb-0.5">{player.name}</div>
        <div className="text-white/40 text-xs font-mono mb-3">{player.currentJob} · Age {player.age}</div>

        {/* Money */}
        <div className="bg-white/4 rounded p-2.5 mb-3 border border-white/6">
          <div className="text-white/40 text-[10px] font-mono uppercase tracking-widest mb-0.5">Balance</div>
          <div className="text-amber-400 font-mono text-lg font-medium">{formatMoney(player.money)}</div>
        </div>

        {/* Health / Happiness */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <StatBar label="Health" value={player.health} color="emerald" />
          <StatBar label="Happiness" value={player.happiness} color="sky" />
        </div>

        {/* Reputation Progress */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-white/40 text-[10px] font-mono uppercase tracking-widest">Reputation</span>
            <span className="text-amber-400 font-mono text-[10px]">{player.reputation} / {repNeeded}</span>
          </div>
          <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-400 rounded-full transition-all duration-500"
              style={{ width: `${repProgress}%` }}
            />
          </div>
          {player.careerTier < 5 && (
            <div className="text-white/25 text-[10px] font-mono mt-1">
              {repNeeded - player.reputation} rep to next tier
            </div>
          )}
        </div>
      </div>

      {/* City Stats Note */}
      <div className="p-4 flex-1">
        <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest mb-3">City Data</div>
        <div className="bg-white/3 border border-white/8 rounded p-3 text-center">
          <div className="text-white/25 text-xs font-sans leading-relaxed mb-2">
            Full city statistics are available on the dedicated City Stats website.
          </div>
          <div className="text-amber-400/50 text-[10px] font-mono">City Net → City Stats</div>
        </div>
      </div>

      {/* Corruption warning */}
      {player.corruption > 20 && (
        <div className="mx-4 mb-4 p-2.5 bg-red-900/20 border border-red-500/30 rounded text-red-400 text-[10px] font-mono">
          ⚠ CORRUPTION HEAT: {player.corruption}%
        </div>
      )}
    </aside>
  );
}

function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    emerald: 'bg-emerald-400',
    sky: 'bg-sky-400',
    amber: 'bg-amber-400',
    red: 'bg-red-400',
  };
  const textMap: Record<string, string> = {
    emerald: 'text-emerald-400',
    sky: 'text-sky-400',
    amber: 'text-amber-400',
    red: 'text-red-400',
  };
  return (
    <div className="bg-white/4 rounded p-2 border border-white/6">
      <div className="text-white/40 text-[9px] font-mono uppercase tracking-widest mb-1">{label}</div>
      <div className="h-1 bg-white/8 rounded-full overflow-hidden mb-1">
        <div className={`h-full rounded-full transition-all duration-500 ${colorMap[color] || 'bg-amber-400'}`} style={{ width: `${value}%` }} />
      </div>
      <div className={`font-mono text-xs ${textMap[color] || 'text-amber-400'}`}>{Math.round(value)}%</div>
    </div>
  );
}
