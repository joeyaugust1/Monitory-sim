// ============================================================
// CIVIC EMPIRE — Reputation Milestone Notification
// Fires a cinematic pop-up when player hits a rep threshold
// ============================================================

import { useEffect, useRef, useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import { getCareerTitle, getReputationForNextTier } from '@/lib/gameEngine';

const MILESTONES = [100, 300, 600, 900];

export default function ReputationNotification() {
  const { state } = useGame();
  const { player } = state;
  const prevRepRef = useRef(player.reputation);
  const shownRef = useRef<Set<number>>(new Set());
  const [notification, setNotification] = useState<{ rep: number; title: string } | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const prev = prevRepRef.current;
    const curr = player.reputation;
    prevRepRef.current = curr;

    for (const milestone of MILESTONES) {
      if (prev < milestone && curr >= milestone && !shownRef.current.has(milestone)) {
        shownRef.current.add(milestone);
        // Determine which tier this unlocks
        const tierUnlocked = milestone === 100 ? 2 : milestone === 300 ? 3 : milestone === 600 ? 4 : 5;
        setNotification({ rep: milestone, title: getCareerTitle(tierUnlocked as any) });
        setVisible(true);
        // Auto-dismiss after 5 seconds
        setTimeout(() => setVisible(false), 5000);
        break;
      }
    }
  }, [player.reputation]);

  if (!notification || !visible) return null;

  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 decision-modal w-full max-w-sm px-4">
      <div className="bg-[#1a1f2e] border border-amber-400/30 rounded-xl p-4 shadow-2xl">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-amber-400/15 border border-amber-400/30 flex items-center justify-center flex-shrink-0">
            <span className="text-amber-400 text-lg">⭐</span>
          </div>
          <div className="flex-1">
            <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-0.5">Reputation Milestone</div>
            <div className="text-white font-serif text-base font-bold mb-1">
              {notification.rep} Reputation Reached
            </div>
            <div className="text-white/60 text-xs font-sans leading-relaxed">
              You are now eligible for <span className="text-amber-400 font-medium">{notification.title}</span> positions. 
              Visit CityJobs to apply for your next career step.
            </div>
          </div>
          <button
            onClick={() => setVisible(false)}
            className="text-white/30 hover:text-white/70 text-lg leading-none flex-shrink-0 transition-colors"
          >
            ×
          </button>
        </div>
      </div>
    </div>
  );
}
