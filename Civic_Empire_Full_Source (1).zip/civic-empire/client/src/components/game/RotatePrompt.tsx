// ============================================================
// CIVIC EMPIRE — Rotate Device Prompt
// Shown when device is in portrait mode.
// Includes a manual override for edge cases.
// ============================================================

const LOGO = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-logo-SurMiAjwNwdtv3HydJ4ina.webp';

interface RotatePromptProps {
  onOverride: () => void;
}

export default function RotatePrompt({ onOverride }: RotatePromptProps) {
  return (
    <div className="fixed inset-0 z-[9999] bg-[#0f1117] flex flex-col items-center justify-center px-8 text-center gap-6">
      <img src={LOGO} alt="Civic Empire" className="w-14 h-14 opacity-80" />

      {/* Animated phone rotate icon */}
      <div className="w-16 h-16 relative">
        <svg viewBox="0 0 64 64" className="w-full h-full" fill="none">
          <rect x="18" y="8" width="28" height="48" rx="4" stroke="rgba(212,160,23,0.35)" strokeWidth="2" />
          <rect x="22" y="13" width="20" height="34" rx="1.5" fill="rgba(212,160,23,0.06)" />
          <circle cx="32" cy="51" r="2" fill="rgba(212,160,23,0.35)" />
          <path d="M44 26 A16 16 0 0 1 20 40" stroke="rgba(212,160,23,0.8)" strokeWidth="2" strokeLinecap="round"
            style={{ animation: 'rotateHint 2s ease-in-out infinite' }} />
          <path d="M16 36 L20 42 L24 38" stroke="rgba(212,160,23,0.8)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
            style={{ animation: 'rotateHint 2s ease-in-out infinite' }} />
        </svg>
      </div>

      <div>
        <h2 className="text-white font-serif text-xl font-bold mb-2">Rotate Your Device</h2>
        <p className="text-white/40 font-sans text-sm leading-relaxed max-w-[260px]">
          Civic Empire is designed for landscape mode. Turn your device sideways to play.
        </p>
      </div>

      {/* Manual override — always available */}
      <button
        onClick={onOverride}
        className="mt-2 px-5 py-2 border border-white/15 bg-white/5 text-white/40 hover:text-white/70 hover:bg-white/10 rounded text-xs font-mono uppercase tracking-widest transition-all duration-150 active:scale-95"
      >
        Continue Anyway
      </button>

      <style>{`
        @keyframes rotateHint {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
