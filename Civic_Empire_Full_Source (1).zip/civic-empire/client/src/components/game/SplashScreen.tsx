// ============================================================
// CIVIC EMPIRE — Splash Screen
// The entry point. Dark, cinematic, authoritative.
// ============================================================

import { useState } from 'react';
import { useGame } from '@/contexts/GameContext';

const SPLASH_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-splash-XCUjtohUyHn7RPAFwVWEVe.webp';
const CITY_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-city-bg-npdx9GBWGg8sGciM9JyXgG.webp';
const LOGO = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-logo-SurMiAjwNwdtv3HydJ4ina.webp';

export default function SplashScreen() {
  const { dispatch } = useGame();
  const [playerName, setPlayerName] = useState('');
  const [step, setStep] = useState<'intro' | 'name'>('intro');

  const handleStart = () => {
    if (step === 'intro') {
      setStep('name');
      return;
    }
    const name = playerName.trim() || 'Alex Mercer';
    dispatch({ type: 'SET_PLAYER_NAME', name });
    dispatch({ type: 'SET_SCREEN', screen: 'game' });
  };

  return (
    <div
      className="fixed inset-0 flex flex-col"
      style={{ backgroundImage: `url(${SPLASH_BG})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-[#0f1117]/85" />

      {/* City bg subtle layer */}
      <div
        className="absolute inset-0 opacity-20"
        style={{ backgroundImage: `url(${CITY_BG})`, backgroundSize: 'cover', backgroundPosition: 'center bottom' }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-6">

        {/* Logo + Title */}
        <div className="text-center mb-12">
          <img src={LOGO} alt="Civic Empire" className="w-24 h-24 mx-auto mb-6 drop-shadow-2xl" />
          <div className="text-amber-400/60 font-mono text-xs uppercase tracking-[0.4em] mb-3">A Political Power Simulator</div>
          <h1 className="text-white font-serif text-6xl font-bold tracking-tight mb-2">
            Civic Empire
          </h1>
          <div className="w-24 h-px bg-amber-400/40 mx-auto mt-4" />
        </div>

        {step === 'intro' ? (
          <div className="max-w-lg text-center">
            <p className="text-white/50 font-sans text-base leading-relaxed mb-8">
              You are nobody. A new face in a city of 142,000. 
              You have a small apartment, a basic job, and an ambition 
              that the city does not yet know about.
            </p>
            <p className="text-amber-400/70 font-sans text-sm leading-relaxed mb-10 italic">
              "Wealth creates influence. Influence creates power. Power creates responsibility. Responsibility creates consequences."
            </p>
            <button
              onClick={handleStart}
              className="px-10 py-3.5 bg-amber-400 text-black font-sans font-semibold text-sm rounded hover:bg-amber-300 transition-all duration-150 active:scale-95 tracking-wide"
            >
              Begin Your Rise
            </button>
          </div>
        ) : (
          <div className="max-w-sm w-full text-center">
            <div className="text-white/60 font-sans text-sm mb-2">What is your name?</div>
            <div className="text-white/30 text-xs font-sans mb-6">The city will remember it.</div>
            <input
              type="text"
              value={playerName}
              onChange={e => setPlayerName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleStart()}
              placeholder="Alex Mercer"
              maxLength={24}
              autoFocus
              className="w-full bg-white/5 border border-white/15 rounded px-4 py-3 text-white font-sans text-base text-center placeholder:text-white/20 focus:outline-none focus:border-amber-400/50 mb-4 transition-colors"
            />
            <button
              onClick={handleStart}
              className="w-full py-3 bg-amber-400 text-black font-sans font-semibold text-sm rounded hover:bg-amber-300 transition-all duration-150 active:scale-95"
            >
              Enter the City
            </button>
          </div>
        )}
      </div>

      {/* Bottom info */}
      <div className="relative z-10 text-center pb-6">
        <div className="text-white/15 text-[10px] font-mono uppercase tracking-widest">
          MVP v0.1 — Stage 1: Citizen · More stages coming
        </div>
      </div>
    </div>
  );
}
