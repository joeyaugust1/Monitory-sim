// ============================================================
// CIVIC EMPIRE — Ticker Bar
// Scrolling news headlines across the top of the screen
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { formatDay } from '@/lib/gameEngine';

export default function TickerBar() {
  const { state } = useGame();
  const { day, month, year } = formatDay(state.gameDay);

  const headlines = state.tickerHeadlines;
  const doubled = [...headlines, ...headlines]; // seamless loop

  return (
    <div className="h-8 bg-[#0a0c12] border-b border-white/10 flex items-center overflow-hidden relative z-50">
      {/* Date badge */}
      <div className="flex-shrink-0 px-3 h-full flex items-center border-r border-white/10 bg-[#0f1117]">
        <span className="text-amber-400 font-mono text-xs font-medium tracking-widest uppercase whitespace-nowrap">
          {month} {day}, Yr {year}
        </span>
      </div>

      {/* LIVE badge */}
      <div className="flex-shrink-0 px-3 h-full flex items-center gap-1.5 border-r border-white/10">
        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
        <span className="text-red-400 font-mono text-xs font-medium tracking-widest uppercase">LIVE</span>
      </div>

      {/* Scrolling headlines */}
      <div className="flex-1 overflow-hidden relative">
        <div className="ticker-track flex items-center gap-0 whitespace-nowrap">
          {doubled.map((headline, i) => (
            <span key={i} className="inline-flex items-center gap-4">
              <span className="text-[#e8e6e1]/70 text-xs font-sans px-4">{headline}</span>
              <span className="text-amber-400/40 text-xs">◆</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
