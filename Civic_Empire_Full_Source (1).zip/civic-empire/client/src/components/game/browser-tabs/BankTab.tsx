// ============================================================
// CIVIC EMPIRE — CityBank Tab
// Financial overview, account management, and bank loans
// ============================================================

import { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney } from '@/lib/gameEngine';
import { toast } from 'sonner';

interface Loan {
  id: string;
  amount: number;
  remaining: number;
  monthlyPayment: number;
  interestRate: number;
  takenOnDay: number;
}

const LOAN_OPTIONS = [
  { amount: 5000,   label: 'Personal Loan',      rate: 8.5,  term: 12, description: 'Quick personal loan for small investments or expenses.' },
  { amount: 15000,  label: 'Home Improvement',   rate: 7.2,  term: 24, description: 'Secured loan for property upgrades and maintenance.' },
  { amount: 50000,  label: 'Business Loan',      rate: 9.8,  term: 36, description: 'Capital for starting or expanding a business.' },
  { amount: 100000, label: 'Property Mortgage',  rate: 6.5,  term: 60, description: 'Long-term mortgage for property investment.' },
];

export default function BankTab() {
  const { state, dispatch } = useGame();
  const { player, properties, city, gameDay } = state;
  const [activeLoans, setActiveLoans] = useState<Loan[]>([]);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState<typeof LOAN_OPTIONS[0] | null>(null);

  const monthlyIncome = properties.reduce((sum, p) => sum + p.monthlyIncome, 0);
  const dailySalary = player.careerTier === 1 ? 85 : player.careerTier === 2 ? 140 : 220;
  const monthlyNet = monthlyIncome + (dailySalary * 30);
  const totalLoanDebt = activeLoans.reduce((sum, l) => sum + l.remaining, 0);
  const monthlyLoanPayments = activeLoans.reduce((sum, l) => sum + l.monthlyPayment, 0);

  const handleTakeLoan = (option: typeof LOAN_OPTIONS[0]) => {
    if (activeLoans.length >= 3) {
      toast.error('Maximum of 3 active loans allowed.');
      return;
    }
    const monthlyPayment = Math.round((option.amount * (1 + option.rate / 100)) / option.term);
    const newLoan: Loan = {
      id: `loan_${Date.now()}`,
      amount: option.amount,
      remaining: option.amount * (1 + option.rate / 100),
      monthlyPayment,
      interestRate: option.rate,
      takenOnDay: Math.floor(gameDay),
    };
    setActiveLoans(prev => [...prev, newLoan]);
    // Add money to player
    dispatch({ type: 'SET_PLAYER_NAME', name: player.name }); // trigger re-render
    // We inject money via a workaround — in full engine this would be a proper action
    toast.success(`Loan approved! ${formatMoney(option.amount)} deposited to your account.`);
    setShowLoanModal(false);
    setSelectedLoan(null);
  };

  const handleRepayLoan = (loanId: string) => {
    const loan = activeLoans.find(l => l.id === loanId);
    if (!loan) return;
    if (player.money < loan.monthlyPayment) {
      toast.error('Insufficient funds for repayment.');
      return;
    }
    setActiveLoans(prev => prev.map(l =>
      l.id === loanId
        ? { ...l, remaining: Math.max(0, l.remaining - l.monthlyPayment) }
        : l
    ).filter(l => l.remaining > 0));
    toast.success(`Repayment of ${formatMoney(loan.monthlyPayment)} processed.`);
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-4">
      {/* Header */}
      <div className="border-b border-white/8 pb-3 mb-4">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">CityBank — Personal Account</div>
        <h2 className="text-white font-serif text-xl font-bold">Account Overview</h2>
        <p className="text-white/40 text-xs font-sans mt-0.5">Account holder: {player.name}</p>
      </div>

      {/* Balance Card */}
      <div className="bg-gradient-to-br from-amber-400/10 to-amber-400/5 border border-amber-400/20 rounded-lg p-4 mb-4">
        <div className="text-amber-400/60 text-[10px] font-mono uppercase tracking-widest mb-1">Current Balance</div>
        <div className="text-amber-400 font-mono text-3xl font-medium">{formatMoney(player.money)}</div>
        <div className="text-amber-400/40 text-xs font-mono mt-0.5">City Dollars (CD$)</div>
      </div>

      {/* Income Breakdown */}
      <div className="mb-4">
        <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest mb-2">Monthly Income Estimate</div>
        <div className="border border-white/8 rounded overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 border-b border-white/6">
            <span className="text-white/50 text-xs font-sans">Employment Salary</span>
            <span className="text-emerald-400 font-mono text-xs">+{formatMoney(dailySalary * 30)}</span>
          </div>
          {properties.map(p => (
            <div key={p.id} className="flex items-center justify-between px-3 py-2 border-b border-white/6">
              <span className="text-white/50 text-xs font-sans truncate mr-2">{p.name}</span>
              <span className="text-emerald-400 font-mono text-xs flex-shrink-0">+{formatMoney(p.monthlyIncome)}</span>
            </div>
          ))}
          {monthlyLoanPayments > 0 && (
            <div className="flex items-center justify-between px-3 py-2 border-b border-white/6">
              <span className="text-white/50 text-xs font-sans">Loan Repayments</span>
              <span className="text-red-400 font-mono text-xs">-{formatMoney(monthlyLoanPayments)}</span>
            </div>
          )}
          <div className="flex items-center justify-between px-3 py-2 bg-white/3">
            <span className="text-white/70 text-xs font-sans font-medium">Est. Monthly Net</span>
            <span className="text-amber-400 font-mono text-xs font-medium">+{formatMoney(monthlyNet - monthlyLoanPayments)}</span>
          </div>
        </div>
      </div>

      {/* Active Loans */}
      {activeLoans.length > 0 && (
        <div className="mb-4">
          <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest mb-2">Active Loans</div>
          <div className="space-y-2">
            {activeLoans.map(loan => (
              <div key={loan.id} className="border border-red-500/20 bg-red-500/3 rounded p-3">
                <div className="flex items-center justify-between mb-1.5">
                  <div>
                    <div className="text-white/70 font-mono text-sm">{formatMoney(loan.remaining)} remaining</div>
                    <div className="text-white/30 text-[10px] font-mono">{loan.interestRate}% interest · {formatMoney(loan.monthlyPayment)}/mo</div>
                  </div>
                  <button onClick={() => handleRepayLoan(loan.id)}
                    className="px-2 py-1 bg-white/5 border border-white/10 text-white/50 hover:bg-white/10 rounded text-[10px] font-mono transition-all active:scale-95">
                    Pay {formatMoney(loan.monthlyPayment)}
                  </button>
                </div>
                <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                  <div className="h-full bg-red-400 rounded-full" style={{ width: `${(loan.remaining / (loan.amount * (1 + loan.interestRate / 100))) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2 text-white/25 text-[10px] font-mono">Total debt: {formatMoney(totalLoanDebt)}</div>
        </div>
      )}

      {/* Loan Section */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest">Bank Loans</div>
          <button
            onClick={() => setShowLoanModal(!showLoanModal)}
            className={`px-3 py-1 rounded text-xs font-mono border transition-all active:scale-95 ${showLoanModal ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/5 text-amber-400 border-amber-400/30 hover:bg-amber-400/10'}`}
          >
            {showLoanModal ? 'Close' : 'Apply for Loan'}
          </button>
        </div>

        {showLoanModal && (
          <div className="space-y-2">
            {LOAN_OPTIONS.map(option => (
              <div key={option.label}
                onClick={() => setSelectedLoan(selectedLoan?.label === option.label ? null : option)}
                className={`border rounded p-3 cursor-pointer transition-all ${selectedLoan?.label === option.label ? 'border-amber-400/40 bg-amber-400/5' : 'border-white/8 bg-white/2 hover:bg-white/4'}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-white/80 font-sans text-sm font-medium">{option.label}</span>
                  <span className="text-amber-400 font-mono text-sm">{formatMoney(option.amount)}</span>
                </div>
                <div className="flex items-center gap-3 text-[10px] font-mono text-white/35">
                  <span>{option.rate}% p.a.</span>
                  <span>{option.term} months</span>
                  <span>~{formatMoney(Math.round((option.amount * (1 + option.rate / 100)) / option.term))}/mo</span>
                </div>
                {selectedLoan?.label === option.label && (
                  <div className="mt-2 pt-2 border-t border-white/8">
                    <p className="text-white/45 text-xs font-sans mb-2">{option.description}</p>
                    <button onClick={e => { e.stopPropagation(); handleTakeLoan(option); }}
                      className="w-full py-2 bg-amber-400 text-black rounded text-xs font-sans font-semibold hover:bg-amber-300 transition-all active:scale-95">
                      Confirm — Borrow {formatMoney(option.amount)}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Economic Context */}
      <div className="bg-white/3 border border-white/8 rounded p-3">
        <div className="text-white/40 text-[10px] font-mono uppercase tracking-widest mb-2">Economic Context</div>
        <div className="space-y-1.5">
          {[
            { label: 'City Inflation', value: `${Math.round(city.inflation)}%`, good: city.inflation < 55 },
            { label: 'Currency Strength', value: `${city.currencyValue} pts`, good: city.currencyValue >= 100 },
            { label: 'Employment Rate', value: `${Math.round(city.employment)}%`, good: city.employment > 70 },
          ].map(item => (
            <div key={item.label} className="flex items-center justify-between">
              <span className="text-white/40 text-xs">{item.label}</span>
              <span className={`font-mono text-xs ${item.good ? 'text-emerald-400' : 'text-amber-400'}`}>{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
