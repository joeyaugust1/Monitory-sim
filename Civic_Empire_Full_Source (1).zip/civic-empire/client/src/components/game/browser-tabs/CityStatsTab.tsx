// ============================================================
// CIVIC EMPIRE — CityData Statistics Website
// All city-level statistics live here, not on the main UI
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { formatDay } from '@/lib/gameEngine';

export default function CityStatsTab() {
  const { state } = useGame();
  const { city, gameDay } = state;
  const { day, month, year } = formatDay(gameDay);

  const stats = [
    { label: 'Employment Rate',       value: city.employment,           suffix: '%', inverse: false, description: 'Percentage of working-age citizens currently employed.' },
    { label: 'Inflation Index',       value: city.inflation,            suffix: '%', inverse: true,  description: 'Current rate of price growth. 50% is considered stable.' },
    { label: 'Housing Affordability', value: city.housingAffordability, suffix: '%', inverse: false, description: 'How affordable homes are relative to average income. Higher is better for renters.' },
    { label: 'Crime Index',           value: city.crime,                suffix: '%', inverse: true,  description: 'Overall crime rate. Lower is better. Affected by unemployment and poverty.' },
    { label: 'City Trust Index',      value: city.cityTrust,            suffix: '%', inverse: false, description: 'Public confidence in city leadership. Critical for elections.' },
    { label: 'Currency Strength',     value: city.currencyValue,        suffix: ' pts', inverse: false, description: '100 = stable. Above 100 = strong currency. Below 100 = weak currency.' },
  ];

  const getBarColor = (value: number, inverse: boolean) => {
    const good = inverse ? value < 40 : value > 60;
    const bad  = inverse ? value > 60 : value < 40;
    if (good) return 'bg-emerald-400';
    if (bad)  return 'bg-red-400';
    return 'bg-amber-400';
  };

  const getTextColor = (value: number, inverse: boolean) => {
    const good = inverse ? value < 40 : value > 60;
    const bad  = inverse ? value > 60 : value < 40;
    if (good) return 'text-emerald-400';
    if (bad)  return 'text-red-400';
    return 'text-amber-400';
  };

  const getLabel = (value: number, inverse: boolean) => {
    const good = inverse ? value < 40 : value > 60;
    const bad  = inverse ? value > 60 : value < 40;
    if (good) return { text: 'Healthy', color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20' };
    if (bad)  return { text: 'Critical', color: 'text-red-400 bg-red-400/10 border-red-400/20' };
    return { text: 'Moderate', color: 'text-amber-400 bg-amber-400/10 border-amber-400/20' };
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-4">
      {/* Header */}
      <div className="border-b border-white/8 pb-3 mb-4">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">CityData.ce — Official Statistics Portal</div>
        <h2 className="text-white font-serif text-xl font-bold">City Statistics</h2>
        <p className="text-white/40 text-xs font-sans mt-0.5">Last updated: {month} {day}, Year {year}</p>
      </div>

      {/* Population banner */}
      <div className="bg-gradient-to-r from-amber-400/10 to-transparent border border-amber-400/15 rounded-lg p-4 mb-4 flex items-center justify-between">
        <div>
          <div className="text-white/40 text-[10px] font-mono uppercase tracking-widest mb-0.5">Total Population</div>
          <div className="text-amber-400 font-mono text-3xl font-medium">{city.population.toLocaleString()}</div>
        </div>
        <div className="text-right">
          <div className="text-white/40 text-[10px] font-mono uppercase tracking-widest mb-0.5">Currency</div>
          <div className={`font-mono text-2xl ${city.currencyValue >= 100 ? 'text-emerald-400' : 'text-red-400'}`}>
            {city.currencyValue} pts
          </div>
          <div className="text-white/25 text-[10px] font-mono">{city.currencyValue >= 100 ? 'Strong' : 'Weak'} City Dollar</div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="space-y-3">
        {stats.map(stat => {
          const status = getLabel(stat.value, stat.inverse);
          const displayValue = stat.label === 'Currency Strength' ? stat.value : Math.round(stat.value);
          const barWidth = stat.label === 'Currency Strength' ? Math.min(100, (stat.value / 200) * 100) : stat.value;
          return (
            <div key={stat.label} className="border border-white/8 bg-white/2 rounded p-3">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-white/80 font-sans text-sm font-medium">{stat.label}</div>
                  <div className="text-white/35 text-[10px] font-sans mt-0.5">{stat.description}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                  <span className={`font-mono text-lg font-medium ${getTextColor(stat.value, stat.inverse)}`}>
                    {displayValue}{stat.suffix}
                  </span>
                  <span className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border ${status.color}`}>
                    {status.text}
                  </span>
                </div>
              </div>
              <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${getBarColor(stat.value, stat.inverse)}`}
                  style={{ width: `${barWidth}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Economic Relationships */}
      <div className="mt-4 p-3 bg-white/3 border border-white/8 rounded">
        <div className="text-white/40 text-[10px] font-mono uppercase tracking-widest mb-2">Key Relationships</div>
        <div className="space-y-1.5 text-[10px] font-sans text-white/35 leading-relaxed">
          <div>↑ Employment → ↑ Spending → ↑ Trust → ↓ Crime</div>
          <div>↑ Inflation → ↓ Purchasing Power → ↓ Trust</div>
          <div>↓ Housing Affordability → ↓ Population → ↓ Employment</div>
          <div>↑ Crime → ↓ Property Values → ↓ City Trust</div>
        </div>
      </div>
    </div>
  );
}
