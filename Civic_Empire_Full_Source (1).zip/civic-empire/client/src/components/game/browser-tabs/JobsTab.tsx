// ============================================================
// CIVIC EMPIRE — CityJobs Tab
// Job listings portal — players apply for career advancement
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { getCareerTitle, getReputationForNextTier } from '@/lib/gameEngine';
import { toast } from 'sonner';

const JOBS = [
  {
    tier: 1,
    title: 'Office Administrator',
    company: 'City Administration Office',
    salary: '$31,000 / year',
    repRequired: 0,
    description: 'Process permit applications, manage departmental paperwork, and support senior staff. Entry-level position.',
    tags: ['Entry Level', 'Full Time'],
  },
  {
    tier: 2,
    title: 'Property Inspector',
    company: 'City Housing Authority',
    salary: '$51,000 / year',
    repRequired: 100,
    description: 'Inspect residential and commercial properties for compliance. Approve or flag building applications. Influence local development.',
    tags: ['Local Authority', 'Full Time'],
  },
  {
    tier: 2,
    title: 'Tax Clerk',
    company: 'City Revenue Office',
    salary: '$48,000 / year',
    repRequired: 100,
    description: 'Manage tax assessments for local businesses and properties. Identify discrepancies and process adjustments.',
    tags: ['Local Authority', 'Full Time'],
  },
  {
    tier: 3,
    title: 'Treasury Officer',
    company: 'City Treasury Department',
    salary: '$80,000 / year',
    repRequired: 300,
    description: 'Manage city budget allocations, advise on fiscal policy, and oversee departmental spending. Direct influence on the city economy.',
    tags: ['Economic Authority', 'Senior'],
  },
  {
    tier: 3,
    title: 'Trade Commissioner',
    company: 'City Commerce Bureau',
    salary: '$88,000 / year',
    repRequired: 300,
    description: 'Negotiate import/export agreements, manage trade incentives, and represent the city in commercial negotiations.',
    tags: ['Economic Authority', 'Senior'],
  },
];

export default function JobsTab() {
  const { state } = useGame();
  const { player } = state;

  const handleApply = (job: typeof JOBS[0]) => {
    if (player.reputation < job.repRequired) {
      toast.error(`Insufficient reputation. You need ${job.repRequired} reputation to apply.`);
      return;
    }
    if (job.tier <= player.careerTier && job.title === player.currentJob) {
      toast.info('You are already in this position.');
      return;
    }
    toast.success(`Application submitted for ${job.title}. Check back in a few days.`);
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-5">
      {/* Header */}
      <div className="border-b border-white/8 pb-4 mb-5">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">CityJobs — Career Portal</div>
        <h2 className="text-white font-serif text-xl font-bold">Job Listings</h2>
        <p className="text-white/40 text-xs font-sans mt-1">
          Your current reputation: <span className="text-amber-400 font-mono">{player.reputation}</span> — 
          Tier: <span className="text-amber-400 font-mono">{getCareerTitle(player.careerTier)}</span>
        </p>
      </div>

      <div className="space-y-3">
        {JOBS.map((job, i) => {
          const canApply = player.reputation >= job.repRequired;
          const isCurrent = job.title === player.currentJob;
          return (
            <div
              key={i}
              className={`border rounded p-4 transition-colors ${
                isCurrent
                  ? 'border-amber-400/30 bg-amber-400/5'
                  : canApply
                  ? 'border-white/10 bg-white/2 hover:bg-white/4'
                  : 'border-white/5 bg-white/1 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <div className="text-white/80 font-sans text-sm font-semibold">{job.title}</div>
                  <div className="text-white/40 text-xs font-sans">{job.company}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-amber-400 font-mono text-xs">{job.salary}</div>
                  <div className="text-white/25 text-[10px] font-mono mt-0.5">
                    {job.repRequired > 0 ? `${job.repRequired} rep req.` : 'No req.'}
                  </div>
                </div>
              </div>
              <p className="text-white/45 text-xs font-sans leading-relaxed mb-3">{job.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex gap-1.5">
                  {job.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-mono px-1.5 py-0.5 bg-white/5 border border-white/10 rounded text-white/40">
                      {tag}
                    </span>
                  ))}
                </div>
                {isCurrent ? (
                  <span className="text-amber-400 text-xs font-mono">Current Position</span>
                ) : (
                  <button
                    onClick={() => handleApply(job)}
                    disabled={!canApply}
                    className={`px-3 py-1 rounded text-xs font-sans font-medium transition-all duration-150 active:scale-95 ${
                      canApply
                        ? 'bg-amber-400 text-black hover:bg-amber-300'
                        : 'bg-white/5 text-white/20 cursor-not-allowed'
                    }`}
                  >
                    {canApply ? 'Apply Now' : `Need ${job.repRequired - player.reputation} more rep`}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-white/3 border border-white/8 rounded">
        <div className="text-white/40 text-xs font-sans leading-relaxed">
          <span className="text-amber-400 font-mono">Note:</span> Senior Authority and City Leader positions are not advertised publicly. 
          They are offered to candidates who have demonstrated exceptional service and public standing. 
          Build your reputation and the city will come to you.
        </div>
      </div>
    </div>
  );
}
