// ============================================================
// CIVIC EMPIRE — CityNews Tab
// Simulated news website — players learn about the city here
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { formatDay } from '@/lib/gameEngine';

const CITY_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663771921202/KjgK39ojw7qtYVNVDtjoLU/civic-empire-city-bg-npdx9GBWGg8sGciM9JyXgG.webp';

const categoryColors: Record<string, string> = {
  economy: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
  politics: 'text-sky-400 bg-sky-400/10 border-sky-400/20',
  crime: 'text-red-400 bg-red-400/10 border-red-400/20',
  housing: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
  general: 'text-white/50 bg-white/5 border-white/10',
};

export default function NewsTab() {
  const { state } = useGame();
  const { news, city, gameDay } = state;
  const { day, month, year } = formatDay(gameDay);

  return (
    <div className="min-h-full bg-[#0f1117]">
      {/* Site Header */}
      <div
        className="relative h-40 flex flex-col justify-end p-5 overflow-hidden"
        style={{ backgroundImage: `url(${CITY_BG})`, backgroundSize: 'cover', backgroundPosition: 'center 60%' }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f1117] via-[#0f1117]/60 to-transparent" />
        <div className="relative z-10">
          <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">
            {month} {day}, Year {year} — City Edition
          </div>
          <div className="text-white font-serif text-2xl font-bold">The City Chronicle</div>
          <div className="text-white/40 text-xs font-sans mt-0.5">Your source for city news, economics & politics</div>
        </div>
      </div>

      {/* City Snapshot Bar */}
      <div className="border-b border-white/8 bg-[#0a0c12] px-5 py-2 flex items-center gap-6 overflow-x-auto">
        <SnapshotStat label="Employment" value={`${Math.round(city.employment)}%`} up={city.employment > 65} />
        <SnapshotStat label="Inflation" value={`${Math.round(city.inflation)}%`} up={city.inflation < 55} />
        <SnapshotStat label="Housing" value={`${Math.round(city.housingAffordability)}%`} up={city.housingAffordability > 55} />
        <SnapshotStat label="Crime" value={`${Math.round(city.crime)}%`} up={city.crime < 30} />
        <SnapshotStat label="Trust" value={`${Math.round(city.cityTrust)}%`} up={city.cityTrust > 55} />
      </div>

      {/* Articles */}
      <div className="p-5 space-y-4">
        {news.length === 0 && (
          <div className="text-white/30 text-sm font-sans text-center py-12">No news yet. Check back soon.</div>
        )}
        {news.map((article, i) => (
          <article
            key={article.id}
            className={`border border-white/8 rounded p-4 bg-white/2 hover:bg-white/4 transition-colors ${i === 0 ? 'border-amber-400/20 bg-amber-400/3' : ''}`}
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <div>
                <span className={`text-[10px] font-mono uppercase tracking-widest px-1.5 py-0.5 rounded border mr-2 ${categoryColors[article.category] || categoryColors.general}`}>
                  {article.category}
                </span>
                {i === 0 && <span className="text-red-400 text-[10px] font-mono uppercase tracking-widest">Breaking</span>}
              </div>
              <span className="text-white/25 text-[10px] font-mono whitespace-nowrap">Day {article.day}</span>
            </div>
            <h3 className={`font-serif font-bold mb-2 leading-snug ${i === 0 ? 'text-lg text-white' : 'text-base text-white/85'}`}>
              {article.headline}
            </h3>
            <p className="text-white/50 text-xs font-sans leading-relaxed">{article.body}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

function SnapshotStat({ label, value, up }: { label: string; value: string; up: boolean }) {
  return (
    <div className="flex items-center gap-1.5 flex-shrink-0">
      <span className="text-white/30 text-[10px] font-mono uppercase">{label}</span>
      <span className={`font-mono text-xs font-medium ${up ? 'text-emerald-400' : 'text-red-400'}`}>
        {up ? '▲' : '▼'} {value}
      </span>
    </div>
  );
}
