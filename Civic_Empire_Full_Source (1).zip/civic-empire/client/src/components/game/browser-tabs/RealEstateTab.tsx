// ============================================================
// CIVIC EMPIRE — PropCity Real Estate Tab
// Buy properties, manage portfolio, maintain assets
// ============================================================

import { useGame } from '@/contexts/GameContext';
import { AVAILABLE_PROPERTIES, formatMoney } from '@/lib/gameEngine';
import { toast } from 'sonner';

export default function RealEstateTab() {
  const { state, dispatch } = useGame();
  const { player, properties, city, gameDay } = state;

  const handleBuy = (propId: string) => {
    const prop = AVAILABLE_PROPERTIES.find(p => p.id === propId);
    if (!prop) return;
    if (player.money < prop.purchasePrice) {
      toast.error('Insufficient funds to purchase this property.');
      return;
    }
    if (properties.find(p => p.id === propId)) {
      toast.info('You already own this property.');
      return;
    }
    dispatch({ type: 'BUY_PROPERTY', propertyId: propId });
    toast.success(`${prop.name} purchased for ${formatMoney(prop.purchasePrice)}.`);
  };

  const handleMaintain = (propId: string) => {
    if (player.money < 200) {
      toast.error('Insufficient funds for maintenance ($200 required).');
      return;
    }
    dispatch({ type: 'MAINTAIN_PROPERTY', propertyId: propId });
    toast.success('Property maintained. Value and income restored.');
  };

  const typeIcons: Record<string, string> = {
    apartment: '🏢', house: '🏠', shop: '🏪', office: '🏗️', factory: '🏭',
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-5">
      {/* Header */}
      <div className="border-b border-white/8 pb-4 mb-5">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">PropCity — Real Estate Portal</div>
        <h2 className="text-white font-serif text-xl font-bold">Property Market</h2>
        <p className="text-white/40 text-xs font-sans mt-1">
          Available balance: <span className="text-amber-400 font-mono">{formatMoney(player.money)}</span>
        </p>
      </div>

      {/* Owned Properties */}
      {properties.length > 0 && (
        <div className="mb-6">
          <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest mb-3">Your Portfolio</div>
          <div className="space-y-3">
            {properties.map(prop => {
              const daysSince = Math.floor(gameDay) - prop.lastMaintained;
              const needsMaintenance = prop.maintenanceLevel < 70;
              return (
                <div key={prop.id} className={`border rounded p-4 ${needsMaintenance ? 'border-amber-400/30 bg-amber-400/3' : 'border-white/10 bg-white/2'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span>{typeIcons[prop.type]}</span>
                      <div>
                        <div className="text-white/80 font-sans text-sm font-semibold">{prop.name}</div>
                        <div className="text-white/35 text-xs font-mono">Value: {formatMoney(prop.currentValue)}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-400 font-mono text-sm">{formatMoney(prop.monthlyIncome)}/mo</div>
                      <div className="text-white/30 text-[10px] font-mono">income</div>
                    </div>
                  </div>

                  {/* Maintenance Bar */}
                  <div className="mb-2">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-white/30 text-[10px] font-mono uppercase">Condition</span>
                      <span className={`text-[10px] font-mono ${prop.maintenanceLevel > 70 ? 'text-emerald-400' : prop.maintenanceLevel > 40 ? 'text-amber-400' : 'text-red-400'}`}>
                        {prop.maintenanceLevel}%
                      </span>
                    </div>
                    <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${prop.maintenanceLevel > 70 ? 'bg-emerald-400' : prop.maintenanceLevel > 40 ? 'bg-amber-400' : 'bg-red-400'}`}
                        style={{ width: `${prop.maintenanceLevel}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-white/25 text-[10px] font-mono">{daysSince} days since last maintenance</span>
                    <button
                      onClick={() => handleMaintain(prop.id)}
                      className={`px-3 py-1 rounded text-xs font-sans font-medium transition-all duration-150 active:scale-95 ${
                        needsMaintenance
                          ? 'bg-amber-400 text-black hover:bg-amber-300'
                          : 'bg-white/5 text-white/40 hover:bg-white/10 border border-white/10'
                      }`}
                    >
                      Maintain — $200
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Available Listings */}
      <div>
        <div className="text-white/50 text-[10px] font-mono uppercase tracking-widest mb-3">Available Listings</div>
        <div className="space-y-3">
          {AVAILABLE_PROPERTIES.map(prop => {
            const owned = !!properties.find(p => p.id === prop.id);
            const canAfford = player.money >= prop.purchasePrice;
            return (
              <div key={prop.id} className={`border rounded p-4 transition-colors ${owned ? 'border-white/5 opacity-40' : canAfford ? 'border-white/10 bg-white/2 hover:bg-white/4' : 'border-white/5 bg-white/1'}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{typeIcons[prop.type]}</span>
                    <div>
                      <div className="text-white/80 font-sans text-sm font-semibold">{prop.name}</div>
                      <div className="text-white/35 text-xs font-mono capitalize">{prop.type}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-amber-400 font-mono text-sm font-medium">{formatMoney(prop.purchasePrice)}</div>
                    <div className="text-emerald-400 font-mono text-xs">{formatMoney(prop.monthlyIncome)}/mo</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-white/25 text-xs font-sans">
                    ROI: ~{((prop.monthlyIncome * 12 / prop.purchasePrice) * 100).toFixed(1)}% annually
                  </div>
                  {owned ? (
                    <span className="text-white/30 text-xs font-mono">Owned</span>
                  ) : (
                    <button
                      onClick={() => handleBuy(prop.id)}
                      disabled={!canAfford}
                      className={`px-3 py-1 rounded text-xs font-sans font-medium transition-all duration-150 active:scale-95 ${
                        canAfford
                          ? 'bg-amber-400 text-black hover:bg-amber-300'
                          : 'bg-white/5 text-white/20 cursor-not-allowed'
                      }`}
                    >
                      {canAfford ? 'Purchase' : 'Insufficient Funds'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Market Note */}
      <div className="mt-5 p-3 bg-white/3 border border-white/8 rounded">
        <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Market Conditions</div>
        <div className="text-white/40 text-xs font-sans">
          Property values are currently influenced by: Employment ({Math.round(city.employment)}%), 
          Crime ({Math.round(city.crime)}%), and Housing Demand. 
          Poorly maintained properties lose value over time.
        </div>
      </div>
    </div>
  );
}
