// ============================================================
// CIVIC EMPIRE — CivicFeed Social Tab
// Simulated social media — public sentiment mirror
// Citizens react to what they believe is happening
// ============================================================

import { useGame } from '@/contexts/GameContext';

interface Post {
  id: string;
  username: string;
  handle: string;
  avatar: string;
  content: string;
  likes: number;
  replies: number;
  time: string;
  sentiment: 'positive' | 'negative' | 'neutral';
}

function generatePosts(employment: number, inflation: number, crime: number, trust: number, housing: number): Post[] {
  const posts: Post[] = [];

  if (employment > 70) {
    posts.push({
      id: 'p1', username: 'Marcus Webb', handle: '@mwebb_city', avatar: 'MW',
      content: 'Just got a new job at the logistics hub downtown. City feels like it\'s moving in the right direction. Employment is up and I\'m seeing more "Help Wanted" signs than ever.',
      likes: 47, replies: 8, time: '2h', sentiment: 'positive',
    });
  } else {
    posts.push({
      id: 'p1', username: 'Marcus Webb', handle: '@mwebb_city', avatar: 'MW',
      content: 'Third application rejection this week. The job market is brutal right now. Something needs to change.',
      likes: 134, replies: 22, time: '2h', sentiment: 'negative',
    });
  }

  if (inflation > 60) {
    posts.push({
      id: 'p2', username: 'Priya Nair', handle: '@priya_northgate', avatar: 'PN',
      content: 'Groceries up 12% since last year. Rent up 8%. My salary has not moved. This is not sustainable. Who is actually in charge of this city?',
      likes: 289, replies: 61, time: '4h', sentiment: 'negative',
    });
  } else {
    posts.push({
      id: 'p2', username: 'Priya Nair', handle: '@priya_northgate', avatar: 'PN',
      content: 'Prices have been pretty stable lately. Not complaining. At least I can still afford my weekly shop without a spreadsheet.',
      likes: 31, replies: 4, time: '4h', sentiment: 'positive',
    });
  }

  if (housing < 50) {
    posts.push({
      id: 'p3', username: 'City Renters Collective', handle: '@cityrenters', avatar: 'CR',
      content: '🔴 HOUSING CRISIS ALERT: Average rent in the city has now exceeded 45% of median income. This is a crisis. We are calling on city officials to act immediately. #AffordableHousing',
      likes: 892, replies: 143, time: '6h', sentiment: 'negative',
    });
  } else {
    posts.push({
      id: 'p3', username: 'City Renters Collective', handle: '@cityrenters', avatar: 'CR',
      content: 'Housing affordability index is holding steady. New apartment developments in the east district are helping. Still work to do, but progress is visible.',
      likes: 156, replies: 18, time: '6h', sentiment: 'positive',
    });
  }

  if (crime > 40) {
    posts.push({
      id: 'p4', username: 'Eastside Residents', handle: '@eastsideresidents', avatar: 'ER',
      content: 'Another break-in on Lakeview Road last night. Three this week. Where are the police? Our neighbourhood is not safe anymore.',
      likes: 445, replies: 87, time: '8h', sentiment: 'negative',
    });
  } else {
    posts.push({
      id: 'p4', username: 'Eastside Residents', handle: '@eastsideresidents', avatar: 'ER',
      content: 'Community patrol has made a real difference on Lakeview Road. Feels safer walking at night. Credit where it\'s due.',
      likes: 203, replies: 29, time: '8h', sentiment: 'positive',
    });
  }

  posts.push({
    id: 'p5', username: 'City Economic Watch', handle: '@cityeconwatch', avatar: 'CE',
    content: `📊 Weekly snapshot: Employment ${Math.round(employment)}% | Inflation ${Math.round(inflation)}% | City Trust ${Math.round(trust)}%. Full analysis on our website.`,
    likes: 67, replies: 12, time: '12h', sentiment: 'neutral',
  });

  return posts;
}

export default function SocialTab() {
  const { state } = useGame();
  const { city } = state;

  const posts = generatePosts(city.employment, city.inflation, city.crime, city.cityTrust, city.housingAffordability);

  const sentimentColors = {
    positive: 'border-l-emerald-500/40',
    negative: 'border-l-red-500/40',
    neutral: 'border-l-white/10',
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-5">
      {/* Header */}
      <div className="border-b border-white/8 pb-4 mb-5">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">CivicFeed — Public Discourse</div>
        <h2 className="text-white font-serif text-xl font-bold">What the City is Saying</h2>
        <p className="text-white/40 text-xs font-sans mt-1">
          Public sentiment reflects what citizens <em>believe</em> is happening — not always the full picture.
        </p>
      </div>

      {/* Sentiment Summary */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white/3 border border-white/8 rounded p-3 text-center">
          <div className="text-emerald-400 font-mono text-lg">{posts.filter(p => p.sentiment === 'positive').length}</div>
          <div className="text-white/30 text-[10px] font-mono uppercase">Positive</div>
        </div>
        <div className="bg-white/3 border border-white/8 rounded p-3 text-center">
          <div className="text-red-400 font-mono text-lg">{posts.filter(p => p.sentiment === 'negative').length}</div>
          <div className="text-white/30 text-[10px] font-mono uppercase">Negative</div>
        </div>
        <div className="bg-white/3 border border-white/8 rounded p-3 text-center">
          <div className="text-amber-400 font-mono text-lg">{Math.round(city.cityTrust)}%</div>
          <div className="text-white/30 text-[10px] font-mono uppercase">Trust Index</div>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="space-y-3">
        {posts.map(post => (
          <div key={post.id} className={`border border-white/8 border-l-2 ${sentimentColors[post.sentiment]} bg-white/2 rounded p-4`}>
            <div className="flex items-start gap-3 mb-2">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 text-xs font-mono flex-shrink-0">
                {post.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-white/80 text-sm font-sans font-medium">{post.username}</span>
                  <span className="text-white/30 text-xs font-mono">{post.handle}</span>
                  <span className="text-white/20 text-xs ml-auto">{post.time}</span>
                </div>
              </div>
            </div>
            <p className="text-white/60 text-sm font-sans leading-relaxed mb-3">{post.content}</p>
            <div className="flex items-center gap-4">
              <span className="text-white/25 text-xs font-mono">♥ {post.likes}</span>
              <span className="text-white/25 text-xs font-mono">💬 {post.replies}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
