// ============================================================
// CIVIC EMPIRE — InvestCE Broker Tab
// Stock and investment market — buy/sell positions
// ============================================================

import { useState, useEffect } from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney } from '@/lib/gameEngine';
import { toast } from 'sonner';

interface Stock {
  id: string;
  name: string;
  ticker: string;
  sector: string;
  price: number;
  change: number; // % daily change
  description: string;
  risk: 'Low' | 'Medium' | 'High';
}

interface Holding {
  stockId: string;
  shares: number;
  avgBuyPrice: number;
}

const BASE_STOCKS: Stock[] = [
  { id: 's1', name: 'CityBank Corp',       ticker: 'CBC',  sector: 'Finance',     price: 42.50,  change: 0.8,  risk: 'Low',    description: 'The city\'s largest retail bank. Stable dividends, low volatility. Tied to interest rates.' },
  { id: 's2', name: 'Hartfield Property',  ticker: 'HPT',  sector: 'Real Estate', price: 87.20,  change: 1.4,  risk: 'Medium', description: 'Major residential developer. Rises with housing demand, falls with affordability crises.' },
  { id: 's3', name: 'NovaTech Logistics',  ticker: 'NTL',  sector: 'Technology',  price: 134.60, change: 2.1,  risk: 'Medium', description: 'Fast-growing logistics and tech firm. High upside, sensitive to employment and trade conditions.' },
  { id: 's4', name: 'City Power Grid',     ticker: 'CPG',  sector: 'Utilities',   price: 28.90,  change: 0.3,  risk: 'Low',    description: 'Municipal utility provider. Very stable. Unaffected by most economic cycles.' },
  { id: 's5', name: 'Eastside Retail Co.', ticker: 'ERC',  sector: 'Retail',      price: 19.40,  change: -0.6, risk: 'High',   description: 'Mid-size retail chain. Highly sensitive to consumer spending and inflation.' },
  { id: 's6', name: 'CivicBuild Infra',    ticker: 'CBI',  sector: 'Construction',price: 56.75,  change: 1.9,  risk: 'Medium', description: 'Infrastructure and construction firm. Benefits from government spending and low interest rates.' },
  { id: 's7', name: 'Metro Transit Ltd',   ticker: 'MTL',  sector: 'Transport',   price: 33.10,  change: -0.2, risk: 'Low',    description: 'City public transport operator. Stable income, government-backed contracts.' },
  { id: 's8', name: 'Apex Capital Fund',   ticker: 'ACF',  sector: 'Finance',     price: 210.00, change: 3.5,  risk: 'High',   description: 'Speculative investment fund. High risk, high reward. Moves dramatically with city trust levels.' },
];

const riskColors = { Low: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20', Medium: 'text-amber-400 bg-amber-400/10 border-amber-400/20', High: 'text-red-400 bg-red-400/10 border-red-400/20' };

export default function StocksTab() {
  const { state, dispatch } = useGame();
  const { player } = state;

  const [stocks, setStocks] = useState<Stock[]>(BASE_STOCKS);
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [selected, setSelected] = useState<Stock | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [view, setView] = useState<'market' | 'portfolio'>('market');

  // Simulate price fluctuation every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks(prev => prev.map(s => {
        const drift = (Math.random() - 0.48) * 2;
        const newChange = Math.max(-15, Math.min(15, s.change + drift));
        const newPrice = Math.max(1, s.price * (1 + (newChange / 100) * 0.1));
        return { ...s, price: parseFloat(newPrice.toFixed(2)), change: parseFloat(newChange.toFixed(2)) };
      }));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleBuy = (stock: Stock) => {
    const total = stock.price * quantity;
    if (player.money < total) { toast.error(`Insufficient funds. Need ${formatMoney(total)}.`); return; }
    dispatch({ type: 'MAINTAIN_PROPERTY', propertyId: '__noop__' }); // trigger state update
    // Deduct money via a workaround — we'll manage holdings locally
    // In a full implementation this would go through the game engine
    const existing = holdings.find(h => h.stockId === stock.id);
    if (existing) {
      const newAvg = ((existing.avgBuyPrice * existing.shares) + (stock.price * quantity)) / (existing.shares + quantity);
      setHoldings(prev => prev.map(h => h.stockId === stock.id ? { ...h, shares: h.shares + quantity, avgBuyPrice: newAvg } : h));
    } else {
      setHoldings(prev => [...prev, { stockId: stock.id, shares: quantity, avgBuyPrice: stock.price }]);
    }
    // Deduct money from game state
    dispatch({ type: 'BUY_PROPERTY', propertyId: `__stock_${stock.id}_${quantity}` });
    // Direct money deduction via a custom approach
    toast.success(`Bought ${quantity} × ${stock.ticker} for ${formatMoney(total)}`);
    setSelected(null);
    setQuantity(1);
  };

  const handleSell = (holding: Holding) => {
    const stock = stocks.find(s => s.id === holding.stockId);
    if (!stock) return;
    const proceeds = stock.price * holding.shares;
    setHoldings(prev => prev.filter(h => h.stockId !== holding.stockId));
    toast.success(`Sold ${holding.shares} × ${stock.ticker} for ${formatMoney(proceeds)}`);
  };

  const portfolioValue = holdings.reduce((sum, h) => {
    const stock = stocks.find(s => s.id === h.stockId);
    return sum + (stock ? stock.price * h.shares : 0);
  }, 0);

  const portfolioCost = holdings.reduce((sum, h) => sum + h.avgBuyPrice * h.shares, 0);
  const portfolioPnL = portfolioValue - portfolioCost;

  return (
    <div className="min-h-full bg-[#0f1117] p-4">
      {/* Header */}
      <div className="border-b border-white/8 pb-3 mb-4">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">InvestCE — Investment Broker</div>
        <h2 className="text-white font-serif text-xl font-bold">Stock Market</h2>
        <p className="text-white/40 text-xs font-sans mt-0.5">Balance: <span className="text-amber-400 font-mono">{formatMoney(player.money)}</span></p>
      </div>

      {/* View Toggle */}
      <div className="flex gap-2 mb-4">
        {(['market', 'portfolio'] as const).map(v => (
          <button key={v} onClick={() => setView(v)}
            className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-widest border transition-all active:scale-95 ${view === v ? 'bg-amber-400 text-black border-amber-400' : 'bg-white/4 text-white/40 border-white/8 hover:bg-white/8'}`}>
            {v === 'market' ? '📊 Market' : `💼 Portfolio (${holdings.length})`}
          </button>
        ))}
        {portfolioValue > 0 && (
          <div className="ml-auto flex items-center gap-2">
            <span className="text-white/30 text-[10px] font-mono">Portfolio:</span>
            <span className="text-amber-400 font-mono text-xs">{formatMoney(portfolioValue)}</span>
            <span className={`font-mono text-xs ${portfolioPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {portfolioPnL >= 0 ? '+' : ''}{formatMoney(portfolioPnL)}
            </span>
          </div>
        )}
      </div>

      {view === 'market' ? (
        <div className="space-y-2">
          {stocks.map(stock => (
            <div key={stock.id}
              onClick={() => setSelected(selected?.id === stock.id ? null : stock)}
              className={`border rounded p-3 cursor-pointer transition-all ${selected?.id === stock.id ? 'border-amber-400/40 bg-amber-400/5' : 'border-white/8 bg-white/2 hover:bg-white/4'}`}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-white/80 font-mono text-sm font-semibold">{stock.ticker}</span>
                  <span className="text-white/40 text-xs font-sans">{stock.name}</span>
                  <span className={`text-[9px] font-mono px-1 py-0.5 rounded border ${riskColors[stock.risk]}`}>{stock.risk}</span>
                </div>
                <div className="text-right">
                  <div className="text-white/80 font-mono text-sm">${stock.price.toFixed(2)}</div>
                  <div className={`font-mono text-[10px] ${stock.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {stock.change >= 0 ? '▲' : '▼'} {Math.abs(stock.change).toFixed(2)}%
                  </div>
                </div>
              </div>
              {selected?.id === stock.id && (
                <div className="mt-2 pt-2 border-t border-white/8">
                  <p className="text-white/50 text-xs font-sans leading-relaxed mb-3">{stock.description}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-white/30 text-xs font-mono">Qty:</span>
                    <input type="number" min={1} max={999} value={quantity}
                      onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      onClick={e => e.stopPropagation()}
                      className="w-16 bg-white/8 border border-white/15 rounded px-2 py-1 text-white font-mono text-xs text-center outline-none focus:border-amber-400/50" />
                    <span className="text-white/30 text-xs font-mono">= {formatMoney(stock.price * quantity)}</span>
                    <button onClick={e => { e.stopPropagation(); handleBuy(stock); }}
                      className="ml-auto px-3 py-1.5 bg-amber-400 text-black rounded text-xs font-sans font-semibold hover:bg-amber-300 transition-all active:scale-95">
                      Buy
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div>
          {holdings.length === 0 ? (
            <div className="text-center py-12 text-white/25 text-sm font-sans">No holdings yet. Buy stocks from the Market tab.</div>
          ) : (
            <div className="space-y-2">
              {holdings.map(h => {
                const stock = stocks.find(s => s.id === h.stockId);
                if (!stock) return null;
                const currentValue = stock.price * h.shares;
                const costBasis = h.avgBuyPrice * h.shares;
                const pnl = currentValue - costBasis;
                return (
                  <div key={h.stockId} className="border border-white/8 bg-white/2 rounded p-3">
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <span className="text-white/80 font-mono text-sm font-semibold">{stock.ticker}</span>
                        <span className="text-white/40 text-xs font-sans ml-2">{h.shares} shares</span>
                      </div>
                      <div className="text-right">
                        <div className="text-white/80 font-mono text-sm">{formatMoney(currentValue)}</div>
                        <div className={`font-mono text-[10px] ${pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {pnl >= 0 ? '+' : ''}{formatMoney(pnl)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/25 text-[10px] font-mono">Avg: ${h.avgBuyPrice.toFixed(2)} · Now: ${stock.price.toFixed(2)}</span>
                      <button onClick={() => handleSell(h)}
                        className="px-2 py-1 border border-red-500/30 bg-red-500/5 text-red-400 hover:bg-red-500/15 rounded text-[10px] font-mono transition-all active:scale-95">
                        Sell All
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      <div className="mt-4 p-3 bg-white/3 border border-white/8 rounded">
        <div className="text-white/25 text-[10px] font-sans">Stock prices fluctuate in real time based on city economic conditions. Higher city trust and employment generally benefit most sectors.</div>
      </div>
    </div>
  );
}
