// ============================================================
// CIVIC EMPIRE — Work Tab
// The job mini-game. Currently: Office Administrator
// Players approve/reject applications to earn money + rep
// ============================================================

import { useState } from 'react';
import { useGame } from '@/contexts/GameContext';
import { formatMoney } from '@/lib/gameEngine';

interface Application {
  id: string;
  applicantName: string;
  requestType: string;
  description: string;
  details: string;
  riskLevel: 'low' | 'medium' | 'high';
  rewardApprove: { money: number; rep: number };
  rewardDeny: { money: number; rep: number };
  consequence?: string;
}

const APPLICATION_POOL: Application[] = [
  {
    id: 'a1',
    applicantName: 'Hartfield Construction Ltd.',
    requestType: 'Building Permit — Residential',
    description: 'Application for a 12-unit residential development on Lakeview Road.',
    details: 'All documentation in order. Environmental assessment completed. Estimated completion: 18 months. Will create approximately 40 construction jobs.',
    riskLevel: 'low',
    rewardApprove: { money: 80, rep: 8 },
    rewardDeny: { money: 60, rep: 4 },
    consequence: 'Approving this will increase housing supply in the area.',
  },
  {
    id: 'a2',
    applicantName: 'QuickBuild Developments',
    requestType: 'Building Permit — Commercial',
    description: 'Application to convert a heritage-listed warehouse into a shopping centre.',
    details: 'Heritage preservation groups have flagged concerns. The developer claims the conversion will create 200 retail jobs. Documentation is incomplete — missing heritage impact assessment.',
    riskLevel: 'high',
    rewardApprove: { money: 100, rep: 5 },
    rewardDeny: { money: 60, rep: 15 },
    consequence: 'Approving without full documentation could expose the department to legal challenge.',
  },
  {
    id: 'a3',
    applicantName: 'Eastside Community Garden Inc.',
    requestType: 'Land Use Permit — Public Space',
    description: 'Request to convert a vacant lot on Eastside Ave into a community garden.',
    details: 'Non-profit application. No commercial activity. Supported by local residents association. Low administrative burden.',
    riskLevel: 'low',
    rewardApprove: { money: 60, rep: 12 },
    rewardDeny: { money: 60, rep: 2 },
  },
  {
    id: 'a4',
    applicantName: 'NovaTech Logistics',
    requestType: 'Zoning Change — Industrial',
    description: 'Application to rezone a residential-adjacent block for light industrial use.',
    details: 'The company plans to build a distribution centre. Residents in the area have submitted 47 objection letters citing noise and traffic concerns. The company is offering to fund a sound barrier.',
    riskLevel: 'medium',
    rewardApprove: { money: 90, rep: 6 },
    rewardDeny: { money: 60, rep: 10 },
    consequence: 'This decision will affect your standing with both business groups and residents.',
  },
  {
    id: 'a5',
    applicantName: 'City Parks Department',
    requestType: 'Infrastructure Grant — Parks',
    description: 'Internal request for $15,000 to refurbish playground equipment in Northgate Park.',
    details: 'Current equipment is 12 years old and has been flagged in a safety audit. Refurbishment is overdue. Budget allocation is available.',
    riskLevel: 'low',
    rewardApprove: { money: 70, rep: 10 },
    rewardDeny: { money: 60, rep: -5 },
    consequence: 'Denying this could create a public safety liability.',
  },
];

export default function WorkTab() {
  const { state, dispatch } = useGame();
  const { player } = state;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lastAction, setLastAction] = useState<{ type: 'approve' | 'deny'; reward: { money: number; rep: number } } | null>(null);
  const [processedCount, setProcessedCount] = useState(0);

  const shuffled = APPLICATION_POOL;
  const app = shuffled[currentIndex % shuffled.length];

  const handleAction = (type: 'approve' | 'deny') => {
    const reward = type === 'approve' ? app.rewardApprove : app.rewardDeny;
    setLastAction({ type, reward });
    // Apply reputation and money gains to the game engine
    dispatch({
      type: 'RESOLVE_EVENT',
      event: {
        id: `work_${app.id}_${Date.now()}`,
        title: app.requestType,
        description: app.description,
        category: 'work',
        day: 0,
        options: [{
          id: 'chosen',
          label: type,
          description: '',
          effects: {
            player: { reputation: reward.rep, money: reward.money },
          },
        }],
      },
      optionId: 'chosen',
    });
    setTimeout(() => {
      setCurrentIndex(i => i + 1);
      setProcessedCount(c => c + 1);
      setLastAction(null);
    }, 1200);
  };

  const riskColors = {
    low: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
    medium: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
    high: 'text-red-400 bg-red-400/10 border-red-400/20',
  };

  return (
    <div className="min-h-full bg-[#0f1117] p-5">
      {/* Header */}
      <div className="border-b border-white/8 pb-4 mb-5">
        <div className="text-amber-400 font-mono text-[10px] uppercase tracking-widest mb-1">City Administration Portal</div>
        <h2 className="text-white font-serif text-xl font-bold">Applications Desk</h2>
        <p className="text-white/40 text-xs font-sans mt-1">
          Review and process incoming permit and grant applications. Your decisions affect the city.
        </p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white/4 border border-white/8 rounded p-3">
          <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Processed Today</div>
          <div className="text-amber-400 font-mono text-lg">{processedCount}</div>
        </div>
        <div className="bg-white/4 border border-white/8 rounded p-3">
          <div className="text-white/30 text-[10px] font-mono uppercase mb-1">In Queue</div>
          <div className="text-white/70 font-mono text-lg">{APPLICATION_POOL.length - (processedCount % APPLICATION_POOL.length)}</div>
        </div>
        <div className="bg-white/4 border border-white/8 rounded p-3">
          <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Reputation</div>
          <div className="text-amber-400 font-mono text-lg">{player.reputation}</div>
        </div>
      </div>

      {/* Application Card */}
      {lastAction ? (
        <div className={`border rounded p-6 text-center transition-all ${lastAction.type === 'approve' ? 'border-emerald-500/40 bg-emerald-500/5' : 'border-red-500/40 bg-red-500/5'}`}>
          <div className={`text-2xl font-serif font-bold mb-2 ${lastAction.type === 'approve' ? 'text-emerald-400' : 'text-red-400'}`}>
            {lastAction.type === 'approve' ? '✓ Approved' : '✗ Denied'}
          </div>
          <div className="text-white/50 text-sm font-sans mb-3">Application processed successfully.</div>
          <div className="flex items-center justify-center gap-4">
            <span className="text-amber-400 font-mono text-sm">+{formatMoney(lastAction.reward.money)}</span>
            <span className="text-white/30">·</span>
            <span className="text-sky-400 font-mono text-sm">+{lastAction.reward.rep} REP</span>
          </div>
        </div>
      ) : (
        <div className="border border-white/10 rounded overflow-hidden">
          {/* Application Header */}
          <div className="bg-[#0a0c12] px-4 py-3 border-b border-white/8 flex items-center justify-between">
            <div>
              <div className="text-white/30 text-[10px] font-mono uppercase tracking-widest">Application #{(currentIndex % APPLICATION_POOL.length) + 1}</div>
              <div className="text-white/80 font-sans text-sm font-semibold mt-0.5">{app.requestType}</div>
            </div>
            <span className={`text-[10px] font-mono uppercase tracking-widest px-2 py-1 rounded border ${riskColors[app.riskLevel]}`}>
              {app.riskLevel} risk
            </span>
          </div>

          {/* Application Body */}
          <div className="p-4 space-y-3">
            <div>
              <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Applicant</div>
              <div className="text-white/80 font-sans text-sm">{app.applicantName}</div>
            </div>
            <div>
              <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Summary</div>
              <div className="text-white/70 font-sans text-sm">{app.description}</div>
            </div>
            <div>
              <div className="text-white/30 text-[10px] font-mono uppercase mb-1">Details</div>
              <div className="text-white/50 font-sans text-xs leading-relaxed">{app.details}</div>
            </div>
            {app.consequence && (
              <div className="bg-amber-400/5 border border-amber-400/20 rounded p-2.5">
                <div className="text-amber-400 text-[10px] font-mono uppercase mb-0.5">⚠ Advisory Note</div>
                <div className="text-amber-400/70 text-xs font-sans">{app.consequence}</div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="px-4 pb-4 grid grid-cols-2 gap-3">
            <button
              onClick={() => handleAction('deny')}
              className="h-10 border border-red-500/30 bg-red-500/5 text-red-400 hover:bg-red-500/15 rounded text-sm font-sans font-medium transition-all duration-150 active:scale-95 flex items-center justify-center gap-2"
            >
              <span>✗</span>
              <span>Deny</span>
              <span className="text-red-400/50 text-xs font-mono">+{app.rewardDeny.rep} rep</span>
            </button>
            <button
              onClick={() => handleAction('approve')}
              className="h-10 border border-emerald-500/30 bg-emerald-500/5 text-emerald-400 hover:bg-emerald-500/15 rounded text-sm font-sans font-medium transition-all duration-150 active:scale-95 flex items-center justify-center gap-2"
            >
              <span>✓</span>
              <span>Approve</span>
              <span className="text-emerald-400/50 text-xs font-mono">+{app.rewardApprove.rep} rep</span>
            </button>
          </div>
        </div>
      )}

      {/* Career Progress Note */}
      {player.reputation < 100 && (
        <div className="mt-4 p-3 bg-white/3 border border-white/8 rounded">
          <div className="text-white/40 text-xs font-sans">
            <span className="text-amber-400 font-mono">{100 - player.reputation} reputation</span> needed to apply for Local Authority positions via CityJobs.
          </div>
        </div>
      )}
    </div>
  );
}
