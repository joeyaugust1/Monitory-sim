// ============================================================
// CIVIC EMPIRE — Game Context
// Global state management + autosave to localStorage
// ============================================================

import React, { createContext, useContext, useReducer, useEffect, useRef } from 'react';
import {
  GameState,
  INITIAL_STATE,
  tickGame,
  applyEventChoice,
  buyProperty,
  maintainProperty,
  GameEvent,
} from '@/lib/gameEngine';

const SAVE_KEY = 'civic_empire_save_v1';
const AUTOSAVE_INTERVAL_MS = 30000; // autosave every 30 seconds

type GameAction =
  | { type: 'TICK'; elapsedMs: number }
  | { type: 'SET_PAUSED'; paused: boolean }
  | { type: 'SET_SPEED'; speed: 1 | 3 }
  | { type: 'SET_SCREEN'; screen: GameState['currentScreen'] }
  | { type: 'SET_BROWSER_TAB'; tab: GameState['activeBrowserTab'] }
  | { type: 'RESOLVE_EVENT'; event: GameEvent; optionId: string }
  | { type: 'BUY_PROPERTY'; propertyId: string }
  | { type: 'MAINTAIN_PROPERTY'; propertyId: string }
  | { type: 'SET_PLAYER_NAME'; name: string }
  | { type: 'LOAD_SAVE'; state: GameState };

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'TICK':
      return tickGame(state, action.elapsedMs);
    case 'SET_PAUSED':
      return { ...state, isPaused: action.paused };
    case 'SET_SPEED':
      return { ...state, timeSpeed: action.speed };
    case 'SET_SCREEN':
      return { ...state, currentScreen: action.screen };
    case 'SET_BROWSER_TAB':
      return { ...state, activeBrowserTab: action.tab };
    case 'RESOLVE_EVENT':
      return applyEventChoice(state, action.event, action.optionId);
    case 'BUY_PROPERTY':
      return buyProperty(state, action.propertyId);
    case 'MAINTAIN_PROPERTY':
      return maintainProperty(state, action.propertyId);
    case 'SET_PLAYER_NAME':
      return { ...state, player: { ...state.player, name: action.name } };
    case 'LOAD_SAVE':
      return action.state;
    default:
      return state;
  }
}

function loadSavedState(): GameState | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GameState;
    // Basic validation
    if (!parsed.player || !parsed.city) return null;
    return parsed;
  } catch {
    return null;
  }
}

function saveState(state: GameState) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  } catch {
    // Storage full or unavailable — fail silently
  }
}

interface GameContextValue {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
  saveNow: () => void;
}

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const saved = loadSavedState();
  const [state, dispatch] = useReducer(gameReducer, saved ?? INITIAL_STATE);
  const lastTickRef = useRef<number>(Date.now());
  const rafRef = useRef<number>(0);
  const lastSaveRef = useRef<number>(Date.now());
  const stateRef = useRef(state);

  // Keep stateRef in sync for autosave
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // Game loop
  useEffect(() => {
    if (state.currentScreen !== 'game') return;

    const loop = () => {
      const now = Date.now();
      const elapsed = now - lastTickRef.current;
      lastTickRef.current = now;

      if (!stateRef.current.isPaused && elapsed > 0 && elapsed < 5000) {
        dispatch({ type: 'TICK', elapsedMs: elapsed });
      }

      // Autosave
      if (now - lastSaveRef.current > AUTOSAVE_INTERVAL_MS) {
        saveState(stateRef.current);
        lastSaveRef.current = now;
      }

      rafRef.current = requestAnimationFrame(loop);
    };

    lastTickRef.current = Date.now();
    rafRef.current = requestAnimationFrame(loop);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [state.currentScreen]);

  // Save on screen change (e.g., entering game from splash)
  useEffect(() => {
    if (state.currentScreen === 'game') {
      saveState(state);
    }
  }, [state.currentScreen]);

  const saveNow = () => saveState(stateRef.current);

  return (
    <GameContext.Provider value={{ state, dispatch, saveNow }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used within GameProvider');
  return ctx;
}
