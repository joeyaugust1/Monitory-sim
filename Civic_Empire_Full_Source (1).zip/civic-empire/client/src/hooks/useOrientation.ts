// ============================================================
// CIVIC EMPIRE — useOrientation hook
// Detects landscape vs portrait reliably across all devices
// ============================================================

import { useState, useEffect } from 'react';

function checkIsLandscape(): boolean {
  if (typeof window === 'undefined') return true;
  // Primary: use window dimensions (most reliable cross-browser)
  return window.innerWidth > window.innerHeight;
}

export function useOrientation() {
  const [isLandscape, setIsLandscape] = useState(true); // default true to avoid flash

  useEffect(() => {
    // Set correct value immediately on mount
    setIsLandscape(checkIsLandscape());

    const handler = () => {
      // Small delay to let the browser finish the orientation change
      // before reading the new dimensions
      setTimeout(() => {
        setIsLandscape(checkIsLandscape());
      }, 100);
    };

    window.addEventListener('resize', handler);
    window.addEventListener('orientationchange', handler);

    return () => {
      window.removeEventListener('resize', handler);
      window.removeEventListener('orientationchange', handler);
    };
  }, []);

  return { isLandscape };
}
