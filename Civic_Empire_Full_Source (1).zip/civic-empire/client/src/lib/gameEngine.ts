// ============================================================
// CIVIC EMPIRE — Core Game Engine
// Design: Every action has consequences. Think long-term.
// ============================================================

export type CareerTier = 1 | 2 | 3 | 4 | 5;

export interface PlayerStats {
  name: string;
  health: number;       // 0–100
  happiness: number;    // 0–100
  money: number;        // City Dollars
  reputation: number;   // 0–1000 — primary advancement metric
  corruption: number;   // 0–100 (hidden heat)
  age: number;          // in-game years
  careerTier: CareerTier;
  currentJob: string;
  daysWorked: number;
}

export interface CityStats {
  employment: number;       // 0–100
  inflation: number;        // 0–100 (50 = stable)
  housingAffordability: number; // 0–100 (higher = more affordable)
  crime: number;            // 0–100
  population: number;       // raw number
  cityTrust: number;        // 0–100
  currencyValue: number;    // 100 = stable
}

export interface Property {
  id: string;
  name: string;
  type: 'apartment' | 'house' | 'shop' | 'office' | 'factory';
  purchasePrice: number;
  currentValue: number;
  monthlyIncome: number;
  maintenanceLevel: number; // 0–100 (100 = perfect)
  lastMaintained: number;   // game day
}

export interface NewsItem {
  id: string;
  headline: string;
  body: string;
  category: 'economy' | 'politics' | 'crime' | 'housing' | 'general';
  day: number;
  impact?: Partial<CityStats>;
}

export interface GameEvent {
  id: string;
  title: string;
  description: string;
  options: EventOption[];
  category: 'work' | 'city' | 'personal' | 'political';
  day: number;
}

export interface EventOption {
  id: string;
  label: string;
  description: string;
  effects: {
    player?: Partial<PlayerStats>;
    city?: Partial<CityStats>;
    delayed?: Array<{ days: number; city?: Partial<CityStats>; player?: Partial<PlayerStats>; newsHeadline?: string }>;
  };
}

export interface DelayedEffect {
  triggerDay: number;
  city?: Partial<CityStats>;
  player?: Partial<PlayerStats>;
  newsHeadline?: string;
}

export interface GameState {
  player: PlayerStats;
  city: CityStats;
  properties: Property[];
  news: NewsItem[];
  pendingEvents: GameEvent[];
  delayedEffects: DelayedEffect[];
  gameDay: number;
  gameYear: number;
  isPaused: boolean;
  timeSpeed: 1 | 3;
  currentScreen: 'splash' | 'game';
  activeBrowserTab: 'news' | 'jobs' | 'realestate' | 'bank' | 'social' | 'work' | 'stocks' | 'citystats';
  lastEventDay: number;
  tickerHeadlines: string[];
}

// ============================================================
// INITIAL STATE
// ============================================================

export const INITIAL_PLAYER: PlayerStats = {
  name: 'Alex Mercer',
  health: 85,
  happiness: 60,
  money: 2500,
  reputation: 12,
  corruption: 0,
  age: 24,
  careerTier: 1,
  currentJob: 'Office Administrator',
  daysWorked: 0,
};

export const INITIAL_CITY: CityStats = {
  employment: 72,
  inflation: 48,
  housingAffordability: 58,
  crime: 28,
  population: 142000,
  cityTrust: 61,
  currencyValue: 100,
};

export const INITIAL_STATE: GameState = {
  player: INITIAL_PLAYER,
  city: INITIAL_CITY,
  properties: [],
  news: generateInitialNews(),
  pendingEvents: [],
  delayedEffects: [],
  gameDay: 1,
  gameYear: 1,
  isPaused: false,
  timeSpeed: 1,
  currentScreen: 'splash',
  activeBrowserTab: 'news',
  lastEventDay: 0,
  tickerHeadlines: [
    'City Employment Rate Holds Steady at 72% — Economists Cautiously Optimistic',
    'Housing Prices Up 3.2% This Quarter — Renters Feel the Squeeze',
    'City Council Debates New Infrastructure Bill — Vote Expected Next Month',
    'Local Tech Sector Reports Record Hiring — 1,200 New Jobs Created',
    'Inflation Remains Moderate — Central Bank Holds Interest Rates',
    'Crime Rate Down 4% in Downtown District — Police Credit Community Patrols',
  ],
};

function generateInitialNews(): NewsItem[] {
  return [
    {
      id: 'n1',
      headline: 'City Employment Rate Holds Steady at 72%',
      body: 'Economists are cautiously optimistic as the city\'s employment rate remains stable heading into the new quarter. The manufacturing and service sectors continue to be the primary drivers of job growth, while the tech sector has seen a modest uptick in hiring activity.',
      category: 'economy',
      day: 1,
    },
    {
      id: 'n2',
      headline: 'Housing Prices Up 3.2% This Quarter',
      body: 'The city\'s housing market continues its upward trend, with average prices rising 3.2% compared to the previous quarter. Renters are feeling the pressure as vacancy rates hit a five-year low. Housing advocacy groups are calling on city officials to increase affordable housing supply.',
      category: 'housing',
      day: 1,
    },
    {
      id: 'n3',
      headline: 'City Trust Index Remains Above 60 — Mayor Praised',
      body: 'A new survey indicates that 61% of citizens express confidence in city leadership, a figure that analysts describe as "healthy but fragile." The index is closely watched as a leading indicator of electoral outcomes.',
      category: 'politics',
      day: 1,
    },
  ];
}

// ============================================================
// WORK EVENTS — Stage 1 (Office Administrator)
// ============================================================

export const WORK_EVENTS_TIER1: GameEvent[] = [
  {
    id: 'we1',
    title: 'Permit Application Review',
    description: 'A local contractor has submitted a permit application to build a new apartment complex in the eastern district. The paperwork is mostly in order, but you notice the proposed site is close to a school.',
    category: 'work',
    day: 0,
    options: [
      {
        id: 'we1a',
        label: 'Approve the Application',
        description: 'Process it quickly. The city needs housing.',
        effects: {
          player: { reputation: 8, money: 50 },
          city: { housingAffordability: 2 },
          delayed: [{ days: 90, city: { crime: 1 }, newsHeadline: 'New Apartment Complex Near Eastside School Raises Safety Concerns' }],
        },
      },
      {
        id: 'we1b',
        label: 'Request Additional Review',
        description: 'Flag the proximity to the school and send it for further assessment.',
        effects: {
          player: { reputation: 15 },
          city: {},
        },
      },
      {
        id: 'we1c',
        label: 'Deny the Application',
        description: 'Reject it on safety grounds. The contractor will be unhappy.',
        effects: {
          player: { reputation: 5, happiness: -5 },
          city: { housingAffordability: -1 },
        },
      },
    ],
  },
  {
    id: 'we2',
    title: 'Budget Allocation Request',
    description: 'Your department has received a discretionary budget request. A local community centre is asking for $500 in administrative support funds. You have the authority to approve or redirect.',
    category: 'work',
    day: 0,
    options: [
      {
        id: 'we2a',
        label: 'Approve the Funding',
        description: 'Support the community centre. It\'s a small amount.',
        effects: {
          player: { reputation: 12, money: -100 },
          city: { cityTrust: 1 },
        },
      },
      {
        id: 'we2b',
        label: 'Redirect to Infrastructure',
        description: 'The roads need it more than a community centre.',
        effects: {
          player: { reputation: 6 },
          city: { employment: 1 },
          delayed: [{ days: 60, city: { cityTrust: -2 }, newsHeadline: 'Community Centre Forced to Cut Programs After Funding Denied' }],
        },
      },
      {
        id: 'we2c',
        label: 'Deny and Pocket the Difference',
        description: 'Quietly redirect the funds. No one will notice... probably.',
        effects: {
          player: { reputation: -5, money: 500, corruption: 10 },
          city: { cityTrust: -1 },
        },
      },
    ],
  },
  {
    id: 'we3',
    title: 'Whistleblower Report',
    description: 'An anonymous tip has landed on your desk alleging that a local construction firm is using substandard materials. If true, it\'s a public safety risk. If false, acting on it could damage an innocent business.',
    category: 'work',
    day: 0,
    options: [
      {
        id: 'we3a',
        label: 'Launch a Formal Investigation',
        description: 'Take it seriously. Public safety comes first.',
        effects: {
          player: { reputation: 20, happiness: 5 },
          city: { cityTrust: 2 },
          delayed: [{ days: 45, city: { employment: -1 }, newsHeadline: 'Construction Firm Under Investigation — Projects Temporarily Halted' }],
        },
      },
      {
        id: 'we3b',
        label: 'Quietly Verify Before Acting',
        description: 'Do some discreet checks first before making it official.',
        effects: {
          player: { reputation: 10 },
          city: {},
        },
      },
      {
        id: 'we3c',
        label: 'Ignore It',
        description: 'Anonymous tips are unreliable. File it away.',
        effects: {
          player: { reputation: -8, happiness: -10 },
          city: {},
          delayed: [{ days: 120, city: { crime: 3, cityTrust: -5 }, newsHeadline: 'Building Collapse Linked to Substandard Materials — Inquiry Launched' }],
        },
      },
    ],
  },
  {
    id: 'we4',
    title: 'Overtime Request',
    description: 'Your supervisor asks if you can work overtime this weekend to clear a backlog of applications. It\'s voluntary, but refusing might affect how you\'re perceived.',
    category: 'work',
    day: 0,
    options: [
      {
        id: 'we4a',
        label: 'Accept — Work the Weekend',
        description: 'Show dedication. The extra money helps too.',
        effects: {
          player: { reputation: 10, money: 200, health: -5, happiness: -5 },
        },
      },
      {
        id: 'we4b',
        label: 'Decline Politely',
        description: 'You need the rest. Work-life balance matters.',
        effects: {
          player: { health: 5, happiness: 5, reputation: -2 },
        },
      },
      {
        id: 'we4c',
        label: 'Negotiate — Work Half the Weekend',
        description: 'Compromise. Show willing without burning out.',
        effects: {
          player: { reputation: 6, money: 100, health: -2 },
        },
      },
    ],
  },
];

// ============================================================
// RANDOM CITY EVENTS
// ============================================================

export const CITY_EVENTS: GameEvent[] = [
  {
    id: 'ce1',
    title: 'Housing Market Warning',
    description: 'The city\'s housing index has risen sharply for the third consecutive month. Analysts are warning of a potential bubble. As a citizen, you must decide how to position your personal finances.',
    category: 'city',
    day: 0,
    options: [
      {
        id: 'ce1a',
        label: 'Buy Property Now — Before Prices Rise Further',
        description: 'Take on debt to buy. If the market keeps rising, you win big.',
        effects: {
          player: { money: -5000, happiness: 5 },
          city: { housingAffordability: -2 },
        },
      },
      {
        id: 'ce1b',
        label: 'Hold Your Cash — Wait for a Correction',
        description: 'Patience. If the bubble bursts, you\'ll buy at a discount.',
        effects: {
          player: { happiness: -3 },
        },
      },
      {
        id: 'ce1c',
        label: 'Sell Any Property You Own',
        description: 'Cash out at the peak. Risky if the market keeps climbing.',
        effects: {
          player: { happiness: 8 },
          city: { housingAffordability: 1 },
        },
      },
    ],
  },
];

// ============================================================
// GAME TICK — called every second of real time
// ============================================================

export function tickGame(state: GameState, elapsedMs: number): GameState {
  if (state.isPaused || state.currentScreen !== 'game') return state;

  // 5 real minutes = 1 game day = 300,000ms
  // At 3x speed: 100,000ms per day
  const msPerDay = state.timeSpeed === 3 ? 100000 : 300000;

  // We accumulate fractional days
  const daysElapsed = elapsedMs / msPerDay;

  const newGameDay = state.gameDay + daysElapsed;
  const fullDaysPassed = Math.floor(newGameDay) - Math.floor(state.gameDay);

  if (fullDaysPassed === 0) {
    return { ...state, gameDay: newGameDay };
  }

  let newState = { ...state, gameDay: newGameDay };

  // Process each full day
  for (let i = 0; i < fullDaysPassed; i++) {
    newState = processDayTick(newState);
  }

  return newState;
}

function processDayTick(state: GameState): GameState {
  let s = { ...state };
  const day = Math.floor(s.gameDay);

  // Update year
  s.gameYear = Math.floor(day / 365) + 1;
  s.player = { ...s.player, age: INITIAL_PLAYER.age + s.gameYear - 1 };

  // Daily salary
  const dailySalary = getDailySalary(s.player.careerTier);
  s.player = { ...s.player, money: s.player.money + dailySalary };

  // Property income (monthly — every 30 days)
  if (day % 30 === 0) {
    let propertyIncome = 0;
    const updatedProperties = s.properties.map(p => {
      // Maintenance decay
      const daysSinceMaintained = day - p.lastMaintained;
      const decay = Math.floor(daysSinceMaintained / 30) * 2;
      const newMaintenance = Math.max(0, p.maintenanceLevel - decay);
      const valueMultiplier = 0.7 + (newMaintenance / 100) * 0.3;
      const income = Math.floor(p.monthlyIncome * valueMultiplier);
      propertyIncome += income;
      return { ...p, maintenanceLevel: newMaintenance, currentValue: Math.floor(p.purchasePrice * valueMultiplier * (1 + (s.city.employment - 50) / 200)) };
    });
    s.properties = updatedProperties;
    s.player = { ...s.player, money: s.player.money + propertyIncome };
  }

  // Process delayed effects
  const remainingEffects: DelayedEffect[] = [];
  for (const effect of s.delayedEffects) {
    if (day >= effect.triggerDay) {
      if (effect.city) s.city = applyPartialCity(s.city, effect.city);
      if (effect.player) s.player = applyPartialPlayer(s.player, effect.player);
      if (effect.newsHeadline) {
        s.news = [generateNewsFromHeadline(effect.newsHeadline, s.city, day), ...s.news].slice(0, 20);
        s.tickerHeadlines = [effect.newsHeadline, ...s.tickerHeadlines].slice(0, 10);
      }
    } else {
      remainingEffects.push(effect);
    }
  }
  s.delayedEffects = remainingEffects;

  // Slow city drift (every 7 days)
  if (day % 7 === 0) {
    s.city = applyCityDrift(s.city, s.player);
  }

  // Trigger work event (every 5–10 days)
  const daysSinceLastEvent = day - s.lastEventDay;
  if (daysSinceLastEvent >= 7 && s.pendingEvents.length === 0) {
    const shouldTrigger = Math.random() < 0.4;
    if (shouldTrigger) {
      const pool = s.player.careerTier === 1 ? WORK_EVENTS_TIER1 : CITY_EVENTS;
      const event = pool[Math.floor(Math.random() * pool.length)];
      s.pendingEvents = [{ ...event, day }];
      s.lastEventDay = day;
      s.isPaused = true; // Auto-pause for event
    }
  }

  // Clamp all values
  s.city = clampCity(s.city);
  s.player = clampPlayer(s.player);

  return s;
}

function getDailySalary(tier: CareerTier): number {
  const salaries: Record<CareerTier, number> = {
    1: 85,   // ~$31k/year
    2: 140,
    3: 220,
    4: 350,
    5: 600,
  };
  return salaries[tier];
}

function applyCityDrift(city: CityStats, player: PlayerStats): CityStats {
  // Natural economic drift based on current state
  let c = { ...city };

  // High employment -> slight inflation
  if (c.employment > 80) c.inflation += 0.3;
  // High inflation -> lower trust
  if (c.inflation > 65) c.cityTrust -= 0.5;
  // High crime -> lower trust and population
  if (c.crime > 50) { c.cityTrust -= 0.3; c.population -= 50; }
  // Good trust -> slight population growth
  if (c.cityTrust > 60) c.population += 30;
  // Low housing affordability -> lower trust
  if (c.housingAffordability < 40) c.cityTrust -= 0.4;

  return c;
}

function applyPartialCity(city: CityStats, partial: Partial<CityStats>): CityStats {
  const c = { ...city };
  if (partial.employment !== undefined) c.employment += partial.employment;
  if (partial.inflation !== undefined) c.inflation += partial.inflation;
  if (partial.housingAffordability !== undefined) c.housingAffordability += partial.housingAffordability;
  if (partial.crime !== undefined) c.crime += partial.crime;
  if (partial.population !== undefined) c.population += partial.population;
  if (partial.cityTrust !== undefined) c.cityTrust += partial.cityTrust;
  if (partial.currencyValue !== undefined) c.currencyValue += partial.currencyValue;
  return c;
}

function applyPartialPlayer(player: PlayerStats, partial: Partial<PlayerStats>): PlayerStats {
  const p = { ...player };
  if (partial.health !== undefined) p.health += partial.health;
  if (partial.happiness !== undefined) p.happiness += partial.happiness;
  if (partial.money !== undefined) p.money += partial.money;
  if (partial.reputation !== undefined) p.reputation += partial.reputation;
  if (partial.corruption !== undefined) p.corruption += partial.corruption;
  return p;
}

function generateNewsFromHeadline(headline: string, city: CityStats, day: number): NewsItem {
  const categories: NewsItem['category'][] = ['economy', 'politics', 'crime', 'housing', 'general'];
  return {
    id: `n_${day}_${Math.random().toString(36).slice(2, 7)}`,
    headline,
    body: `Reporting from City Hall — ${headline}. City officials have been made aware of the situation and are expected to respond in the coming days.`,
    category: categories[Math.floor(Math.random() * categories.length)],
    day,
  };
}

function clampCity(city: CityStats): CityStats {
  return {
    employment: Math.max(0, Math.min(100, city.employment)),
    inflation: Math.max(0, Math.min(100, city.inflation)),
    housingAffordability: Math.max(0, Math.min(100, city.housingAffordability)),
    crime: Math.max(0, Math.min(100, city.crime)),
    population: Math.max(0, city.population),
    cityTrust: Math.max(0, Math.min(100, city.cityTrust)),
    currencyValue: Math.max(20, Math.min(200, city.currencyValue)),
  };
}

function clampPlayer(player: PlayerStats): PlayerStats {
  return {
    ...player,
    health: Math.max(0, Math.min(100, player.health)),
    happiness: Math.max(0, Math.min(100, player.happiness)),
    money: Math.max(0, player.money),
    reputation: Math.max(0, Math.min(1000, player.reputation)),
    corruption: Math.max(0, Math.min(100, player.corruption)),
  };
}

// ============================================================
// APPLY EVENT CHOICE
// ============================================================

export function applyEventChoice(state: GameState, event: GameEvent, optionId: string): GameState {
  const option = event.options.find(o => o.id === optionId);
  if (!option) return state;

  let s = { ...state };
  const day = Math.floor(s.gameDay);

  if (option.effects.player) s.player = applyPartialPlayer(s.player, option.effects.player);
  if (option.effects.city) s.city = applyPartialCity(s.city, option.effects.city);

  if (option.effects.delayed) {
    const newDelayed: DelayedEffect[] = option.effects.delayed.map(d => ({
      triggerDay: day + d.days,
      city: d.city,
      player: d.player,
      newsHeadline: d.newsHeadline,
    }));
    s.delayedEffects = [...s.delayedEffects, ...newDelayed];
  }

  s.pendingEvents = s.pendingEvents.filter(e => e.id !== event.id);
  s.isPaused = false;

  s.city = clampCity(s.city);
  s.player = clampPlayer(s.player);

  return s;
}

// ============================================================
// PROPERTY ACTIONS
// ============================================================

export const AVAILABLE_PROPERTIES: Property[] = [
  {
    id: 'prop1',
    name: 'Studio Apartment — Eastside',
    type: 'apartment',
    purchasePrice: 45000,
    currentValue: 45000,
    monthlyIncome: 650,
    maintenanceLevel: 100,
    lastMaintained: 0,
  },
  {
    id: 'prop2',
    name: '2-Bed House — Northgate',
    type: 'house',
    purchasePrice: 120000,
    currentValue: 120000,
    monthlyIncome: 1400,
    maintenanceLevel: 100,
    lastMaintained: 0,
  },
  {
    id: 'prop3',
    name: 'Corner Shop — Market District',
    type: 'shop',
    purchasePrice: 85000,
    currentValue: 85000,
    monthlyIncome: 1800,
    maintenanceLevel: 100,
    lastMaintained: 0,
  },
];

export function buyProperty(state: GameState, propertyId: string): GameState {
  const prop = AVAILABLE_PROPERTIES.find(p => p.id === propertyId);
  if (!prop) return state;
  if (state.player.money < prop.purchasePrice) return state;
  if (state.properties.find(p => p.id === propertyId)) return state;

  return {
    ...state,
    player: { ...state.player, money: state.player.money - prop.purchasePrice },
    properties: [...state.properties, { ...prop, lastMaintained: Math.floor(state.gameDay) }],
  };
}

export function maintainProperty(state: GameState, propertyId: string): GameState {
  const MAINTENANCE_COST = 200;
  if (state.player.money < MAINTENANCE_COST) return state;

  return {
    ...state,
    player: { ...state.player, money: state.player.money - MAINTENANCE_COST },
    properties: state.properties.map(p =>
      p.id === propertyId
        ? { ...p, maintenanceLevel: 100, lastMaintained: Math.floor(state.gameDay) }
        : p
    ),
  };
}

// ============================================================
// HELPERS
// ============================================================

export function formatMoney(amount: number): string {
  if (amount >= 1000000) return `$${(amount / 1000000).toFixed(2)}M`;
  if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`;
  return `$${amount.toFixed(0)}`;
}

export function formatDay(gameDay: number): { day: number; month: string; year: number } {
  const totalDays = Math.floor(gameDay);
  const year = Math.floor(totalDays / 365) + 1;
  const dayOfYear = totalDays % 365;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthIndex = Math.floor(dayOfYear / 30);
  const day = (dayOfYear % 30) + 1;
  return { day, month: months[Math.min(monthIndex, 11)], year };
}

export function getStatColor(value: number, inverse = false): string {
  const good = inverse ? value < 40 : value > 60;
  const bad = inverse ? value > 60 : value < 40;
  if (good) return 'text-emerald-400';
  if (bad) return 'text-red-400';
  return 'text-amber-400';
}

export function getCareerTitle(tier: CareerTier): string {
  const titles: Record<CareerTier, string> = {
    1: 'Citizen',
    2: 'Local Authority',
    3: 'Economic Authority',
    4: 'Senior Authority',
    5: 'City Leader',
  };
  return titles[tier];
}

export function getReputationForNextTier(tier: CareerTier): number {
  const thresholds: Record<CareerTier, number> = {
    1: 100,
    2: 300,
    3: 600,
    4: 900,
    5: 1000,
  };
  return thresholds[tier];
}
