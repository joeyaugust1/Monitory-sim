# Civic Empire — Design Brainstorm

## Three Stylistic Approaches

### Approach A: "Brutalist Newsroom"
A raw, editorial aesthetic inspired by financial newspapers and government documents. Monochrome base with stark typography, dense information grids, and a single aggressive accent color (blood orange). Feels like a real government terminal.
**Probability: 0.04**

### Approach B: "Neon Noir City"
A dark, cyberpunk-adjacent aesthetic with glowing neon accents, dark glass panels, and a city-at-night atmosphere. Inspired by Blade Runner and SimCity's night mode. Deep navy/charcoal backgrounds with electric teal and amber highlights.
**Probability: 0.07**

### Approach C: "Executive Dark — Political Thriller"
A premium, dark-mode executive dashboard. Think the Oval Office meets Bloomberg Terminal. Deep charcoal and slate backgrounds, gold/amber accent color, sharp serif display font for headings, clean monospace for data. Feels authoritative, high-stakes, and cinematic.
**Probability: 0.09**

---

## ✅ CHOSEN APPROACH: C — "Executive Dark — Political Thriller"

This approach best matches the game's tone: a serious, high-stakes political and economic simulator where the player is climbing to the top of a city's power structure. It should feel like you are operating in a world of real consequence.

---

## Design Philosophy

**Design Movement:** Dark Executive / Political Thriller Dashboard. Inspired by Bloomberg Terminal, The West Wing, and Succession's visual language.

**Core Principles:**
1. **Authority through restraint** — every element earns its place. No decorative clutter.
2. **Data as drama** — numbers and stats are presented with cinematic weight, not as dry spreadsheets.
3. **Asymmetric information hierarchy** — the layout is intentionally unbalanced to create visual tension.
4. **The "Fake Internet" as the primary interaction layer** — the simulated browser feels like a real tool, not a game UI.

**Color Philosophy:**
- **Background:** Deep charcoal `#0f1117` — the color of a late-night office
- **Surface:** Slate panels `#1a1f2e` — layered depth
- **Signature Brand Color:** Amber Gold `#d4a017` — power, wealth, authority. Used sparingly for key data and CTAs.
- **Accent 2:** Electric Teal `#00c9a7` — for positive economic indicators
- **Destructive:** Crimson `#e63946` — for negative indicators, warnings
- **Text:** Off-white `#e8e6e1` on dark, warm-tinted to feel less clinical

**Layout Paradigm:**
- Split-screen: Left sidebar (player stats + time bar) + Main content area (the "Fake Internet" browser)
- The main content area mimics a real browser window, with tabs for different "websites"
- Stats are shown as live-updating numbers in the sidebar, not as a HUD overlay

**Signature Elements:**
1. A persistent "City Ticker" bar at the top — scrolling news headlines like a stock ticker
2. The "Fake Internet" browser chrome — complete with address bar, tabs, and a simulated URL
3. Amber gold data highlights — key numbers glow amber when they change

**Interaction Philosophy:**
Interactions feel deliberate and consequential. Buttons have a firm, physical press feel. Decision modals are cinematic — they darken the background and present choices with weight.

**Animation:**
- Time bar fills smoothly and continuously
- Stat changes animate with a number-count-up effect
- Decision modals slide in from the bottom with a 250ms ease-out
- Tab switching in the fake browser is instant (no animation — feels like a real browser)
- Ticker scrolls at a slow, readable pace

**Typography System:**
- **Display/Headings:** `Playfair Display` — authoritative serif for the game title and major headings
- **UI/Body:** `IBM Plex Sans` — clean, slightly technical sans-serif for all UI text
- **Data/Numbers:** `IBM Plex Mono` — monospace for all stats, money values, and data

**Brand Essence:** A political power simulator for players who want to feel the weight of real decisions — for the strategist, the schemer, and the statesman.

**Brand Voice:** Serious, dry, occasionally sardonic. Headlines sound like real news. CTAs are direct commands.
- Example: *"The city is watching. What will you do?"*
- Example: *"Apply for Position"* (not "Get Started!")

**Wordmark & Logo:** A stylized city skyline silhouette compressed into a shield/crest shape, rendered in amber gold on dark.

**Signature Brand Color:** Amber Gold `#d4a017`
